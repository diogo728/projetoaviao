// Luzes da pista: pontos luminosos que so se desenham no modo noturno.
#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <string>

struct RunwayLights {
    GLuint vao = 0;
    GLsizei count = 0;      // numero de luzes
};

// le models/runway_lights.obj e cria um ponto luminoso por luz
RunwayLights buildLightSprites(const std::string& objPath);

// desenha os pontos (aditivos, sem escrever profundidade); so aparecem com night > 0.01
void drawRunwayLights(GLuint ptProg, const RunwayLights& lights, const glm::mat4& view, const glm::mat4& proj,
                      const glm::vec3& eye, float time, float night, int framebufferHeight);
