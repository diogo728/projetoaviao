// Renderizacao: camaras, pose do aviao, desenho do aviao (trem e helice) e HUD na barra de titulo.
#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include "aircraft.hpp"
#include "model.hpp"
#include "sky.hpp"

// Estado das camaras (1 seguimento, 2 asa)
struct Camera {
    int mode = 1;
    bool init = false;                                 // foco suavizado da camara de seguimento
    glm::vec3 f{0.0f, 0.0f, 1.0f}, u{0.0f, 1.0f, 0.0f};   // eixos suavizados da camara de seguimento
    float yaw = 0.0f, pitch = 14.0f, dist = 22.25f;    // orbita do rato: graus / graus / metros
};

// matrizes e posicao do olho num fotograma
struct View {
    glm::mat4 view{1.0f}, proj{1.0f};
    glm::vec3 eye{0.0f};
};

// calcula a altura do aviao (contacto com o solo ou voo) e devolve a matriz de modelo
glm::mat4 updatePlanePose(Aircraft& ac, const Model& plane, float planeScale, const glm::vec3& planePivot,
                          float modelYaw);
// atualiza a camara escolhida e devolve view/proj
View updateCamera(Camera& cam, const Aircraft& ac, const glm::mat4& planeM, float dt, float aspect);
// uniformes comuns da cena (luz, neblina, camara)
void beginScene(GLuint prog, const View& v, const Aircraft& ac, const Sky& sky, const SkyLook& look);
void setModelMatrix(GLuint prog, const glm::mat4& M);
// aviao completo: corpo, trem (a recolher) e helice
void drawPlane(GLuint prog, const Model& plane, const glm::mat4& M, const Aircraft& ac);
// HUD na barra de titulo
void updateTitle(GLFWwindow* win, const Aircraft& ac, const Told& told, bool assist, int camMode,
                 const char* skyTitle);
