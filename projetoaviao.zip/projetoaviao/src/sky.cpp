#include "sky.hpp"

#include <glm/gtc/matrix_transform.hpp>

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <sstream>

#include "stb_image.h"      // so as declaracoes (a implementacao esta em model.cpp)

// ---- leitura de skybox/skies.txt: uma linha por ceu ----
static bool loadSkyList(const std::string& file, std::vector<SkyInfo>& out) {
    std::ifstream f(file);
    if (!f) return false;
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream ss(line);
        SkyInfo s;
        ss >> s.name >> s.cat >> s.lightCol.r >> s.lightCol.g >> s.lightCol.b >> s.ambient
           >> s.lightDir.x >> s.lightDir.y >> s.lightDir.z >> s.fog.r >> s.fog.g >> s.fog.b >> s.night;
        if (!ss) continue;
        std::getline(ss, s.title);
        size_t i = s.title.find_first_not_of(" \t");
        s.title = i == std::string::npos ? s.name : s.title.substr(i);
        while (!s.title.empty() && (s.title.back() == '\r' || s.title.back() == ' ')) s.title.pop_back();
        out.push_back(s);
    }
    return !out.empty();
}

// ---- cubemap: seis faces JPG numa textura GL_TEXTURE_CUBE_MAP ----
static GLuint loadCubemap(const std::string& dir) {
    const char* face[6] = {"px", "nx", "py", "ny", "pz", "nz"};     // ordem GL_TEXTURE_CUBE_MAP_POSITIVE_X + i
    GLuint t = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_CUBE_MAP, t);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    stbi_set_flip_vertically_on_load(0);
    for (int i = 0; i < 6; ++i) {
        std::string path = dir + "/" + face[i] + ".jpg";
        int w = 0, h = 0, n = 0;
        unsigned char* d = stbi_load(path.c_str(), &w, &h, &n, 3);
        if (!d) { std::fprintf(stderr, "[aviso] nao abri %s\n", path.c_str()); glDeleteTextures(1, &t); return 0; }
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_SRGB8, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, d);
        stbi_image_free(d);
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    return t;
}

// escolhe o ceu idx: troca o cubemap, a direcao da luz e o alvo dia/noite
void selectSky(Sky& sky, int idx) {
    if (idx < 0 || idx >= (int)sky.skies.size()) return;
    GLuint t = loadCubemap(sky.root + "/" + sky.skies[idx].name);
    if (!t) return;
    if (sky.cube) glDeleteTextures(1, &sky.cube);
    sky.cube = t;
    sky.idx = idx;
    const SkyInfo& s = sky.skies[idx];
    sky.lightOff = glm::normalize(s.lightDir) * 850.0f;      // a luz da cena vem de onde esta o sol/lua da imagem
    sky.nightTarget = s.night;
    std::printf("Ceu: %s (%s)\n", s.title.c_str(), s.name.c_str());
}

void toggleDayNight(Sky& sky) {
    if (sky.skies.size() < 2) {
        std::fprintf(stderr, "Sao necessarios os ceus diurno e noturno para alternar com M.\n");
        return;
    }
    selectSky(sky, sky.idx == 0 ? 1 : 0);
}

void initSky(Sky& sky, const std::string& skyRoot, GLuint skyProg) {
    sky.root = skyRoot;
    sky.prog = skyProg;
    glGenVertexArrays(1, &sky.emptyVao);
    if (loadSkyList(sky.root + "/skies.txt", sky.skies)) {
        std::printf("Skybox: %zu ceus em %s\n", sky.skies.size(), sky.root.c_str());
        selectSky(sky, 0);
    } else {
        std::printf("(sem pasta skybox: a usar o ceu de reserva)\n");
    }
}

// transicao dia <-> noite (2 s)
void updateNight(Sky& sky, float dt) {
    float tgt = sky.nightTarget;
    if (sky.night < tgt) sky.night = std::min(sky.night + dt * 0.5f, tgt);
    else                 sky.night = std::max(sky.night - dt * 0.5f, tgt);
}

// cor do horizonte (neblina), cor da luz e ambiente: do skies.txt, ou valores de reserva sem skybox
SkyLook skyLook(const Sky& sky) {
    const float nt = sky.night;
    auto lin = [](const glm::vec3& g) { return glm::pow(g, glm::vec3(2.2f)); };
    SkyLook look;
    if (sky.idx >= 0) {                                    // valores vindos de skybox/skies.txt
        const SkyInfo& si = sky.skies[sky.idx];
        look.horizon = lin(si.fog); look.lightCol = si.lightCol; look.ambient = si.ambient;
    } else {                                               // reserva: ceu simples sem skybox
        look.horizon  = glm::mix(lin(glm::vec3(0.70f, 0.82f, 0.95f)), lin(glm::vec3(0.03f, 0.04f, 0.08f)), nt);
        look.lightCol = glm::mix(glm::vec3(1.0f, 0.97f, 0.90f), glm::vec3(0.22f, 0.26f, 0.42f), nt);
        look.ambient  = glm::mix(0.28f, 0.10f, nt);
    }
    return look;
}

const char* skyTitle(const Sky& sky) {
    return sky.idx >= 0 ? sky.skies[sky.idx].title.c_str() : "ceu";
}

// ---- ceu: triangulo de ecra inteiro, sem teste de profundidade ----
void drawSky(const Sky& sky, const SkyLook& look, const glm::mat4& view, const glm::mat4& proj,
             const glm::vec3& eye) {
    const bool haveSky = sky.idx >= 0;
    glm::vec3 zenith = look.horizon;                       // com skybox o zenite coincide com o horizonte
    if (!haveSky) {                                        // reserva: ceu simples sem skybox
        auto lin = [](const glm::vec3& g) { return glm::pow(g, glm::vec3(2.2f)); };
        zenith = glm::mix(lin(glm::vec3(0.18f, 0.40f, 0.82f)), lin(glm::vec3(0.002f, 0.004f, 0.02f)), sky.night);
    }
    const glm::vec3 sunDir = glm::normalize(sky.lightOff);
    glDisable(GL_DEPTH_TEST);
    glUseProgram(sky.prog);
    glm::mat4 invVP = glm::inverse(proj * view);
    glUniformMatrix4fv(glGetUniformLocation(sky.prog, "uInvVP"), 1, GL_FALSE, &invVP[0][0]);
    glUniform3f(glGetUniformLocation(sky.prog, "uCamPos"), eye.x, eye.y, eye.z);
    glUniform3f(glGetUniformLocation(sky.prog, "uSunDir"), sunDir.x, sunDir.y, sunDir.z);
    glUniform3f(glGetUniformLocation(sky.prog, "uHorizon"), look.horizon.r, look.horizon.g, look.horizon.b);
    glUniform3f(glGetUniformLocation(sky.prog, "uZenith"), zenith.r, zenith.g, zenith.b);
    glUniform1f(glGetUniformLocation(sky.prog, "uNight"), sky.night);
    glUniform1i(glGetUniformLocation(sky.prog, "uUseCube"), haveSky ? 1 : 0);
    glUniform1i(glGetUniformLocation(sky.prog, "uCube"), 1);
    if (haveSky) { glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_CUBE_MAP, sky.cube); glActiveTexture(GL_TEXTURE0); }
    glBindVertexArray(sky.emptyVao);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glEnable(GL_DEPTH_TEST);
}

void destroySky(Sky& sky) {
    if (sky.cube) glDeleteTextures(1, &sky.cube);
    sky.cube = 0;
}
