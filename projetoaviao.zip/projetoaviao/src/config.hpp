// Constantes da pista, partilhadas pelo modelo de voo (aircraft) e pelo programa principal.
#pragma once

// ----------------------------------------------------------------------------
// Pista, em metros. O modelo runway_short.obj e um troco central da pista
// original: 3200 unidades de comprimento e 113.85 de largura de asfalto.
// Uma escala uniforme leva o asfalto a 45 m (largura da pista 05/23 do
// aeroporto da Madeira, LPMA), o que da um troco de cerca de 1265 m.
// ----------------------------------------------------------------------------
namespace cfg {
constexpr float RUNWAY_MODEL_LENGTH = 3200.0f;
constexpr float RUNWAY_MODEL_WIDTH = 113.852722f;
constexpr float RUNWAY_WIDTH = 45.0f;
constexpr float RUNWAY_SCALE = RUNWAY_WIDTH / RUNWAY_MODEL_WIDTH;
constexpr float RUNWAY_LENGTH = RUNWAY_MODEL_LENGTH * RUNWAY_SCALE;
constexpr float RUNWAY_HALF = RUNWAY_LENGTH * 0.5f;
constexpr float START_SETBACK = 30.0f;          // o aviao arranca 30 m depois da cabeceira
constexpr float EDGE_LIGHT_X = RUNWAY_WIDTH * 0.5f - 0.5f;   // luzes de bordo a 0.5 m do limite do asfalto
}
