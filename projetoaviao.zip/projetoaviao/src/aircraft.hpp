// Estado do aviao e simulacao da descolagem (modelo de voo, sem OpenGL).
#pragma once
#include <glm/glm.hpp>
#include <functional>

#include "config.hpp"

enum class Phase { Ready, GroundRoll, Rotation, Climb, Crashed };

// ----------------------------------------------------------------------------
// Modelo de voo (ponto material no plano vertical), em unidades SI.
// Valores publicados do Ki-61-I: comprimento 8.94 m, envergadura 12.0 m,
// area alar 20 m2, massa 3470 kg, potencia 1175 hp, subida inicial 15.2 m/s.
// Estimativas: coeficientes aerodinamicos, tracao estatica, resistencia ao
// rolamento e velocidades de manobra do piloto (ver README).
// ----------------------------------------------------------------------------
struct AircraftSpec {
    const char* name = "Kawasaki Ki-61 Hien";
    const char* modelFile = "kawasaki.obj";
    float length = 8.94f;               // m
    float modelYaw = 180.0f;            // orientacao do modelo OBJ (graus)
    float mass = 3470.0f;               // kg
    float wingArea = 20.0f;             // m2
    float wingSpan = 12.0f;             // m
    float power = 1175.0f * 745.7f;     // W (Ha-40, potencia de descolagem)
    float staticThrust = 11000.0f;      // N (limite da tracao a baixa velocidade)
    float propEfficiency = 0.80f;
    float cd0 = 0.026f, cdGear = 0.015f, cdFlaps = 0.010f, oswald = 0.80f;
    float clAlpha = 0.09f;              // por grau (asa de alongamento 7.2)
    float alphaZeroLift = 3.0f;         // graus (incidencia + curvatura)
    float clMax = 1.55f;                // com flaps de descolagem (Vs ~ 150 km/h)
    float rollingResistance = 0.03f;
    float throttleTime = 3.0f;          // s ate a potencia maxima
    float tailUpSpeed = 95.0f / 3.6f;   // m/s: a cauda sobe
    float rotationSpeed = 140.0f / 3.6f;// m/s: o piloto puxa o nariz
    float groundPitch = 13.1f;          // graus: atitude de 3 pontos (da geometria do modelo)
    float rotationPitch = 11.0f;        // graus: atitude comandada na rotacao
    float climbSpeed = 230.0f / 3.6f;   // m/s: velocidade de subida (< limite de 250 km/h com trem)
    float gearRetractHeight = 10.0f;    // m
    float gearRetractTime = 6.0f;       // s
    float propSpoolTime = 5.0f;         // s ate a helice atingir a rotacao maxima
    float maxPropSpinRate = 1800.0f;    // graus/s (limite visual)
    // controlo manual (apos a recolha completa do trem)
    float maxPitchRate = 15.0f;         // graus/s com a pancada de manche a fundo
    float maxRollRate = 70.0f;          // graus/s (Ki-61 a ~230 km/h; estimativa)
    float levelRate = 15.0f;            // graus/s: nivelamento das asas sem comando
    float stallDragCoef = 1.2f;         // resistencia da asa em perda (placa plana ~ 1.2 sin^2)
    float maxSpeed = 750.0f / 3.6f;     // m/s: limite de velocidade em picada (estimativa)
    float runwayStartZ = -cfg::RUNWAY_HALF + cfg::START_SETBACK;
};

// comandos do piloto, de -1 a 1: pitch > 0 = nariz para cima; roll > 0 = asa direita para baixo
struct Controls {
    float pitch = 0.0f, roll = 0.0f;
    bool assist = true;     // estabilizador: nivela as asas (so ate 90 graus de rolamento) sem comando de rolamento
};

// altura do terreno sob o aviao (definida pelo programa); sem ela o solo e plano em y = 0
extern std::function<float(float, float)> groundHeightFn;

struct Aircraft {
    glm::vec3 pos{0.0f};          // pos.y e calculado no desenho (altura + contacto com o solo)
    float yaw = 0.0f, pitch = 0.0f, roll = 0.0f;
    float speed = 0.0f;           // m/s, ao longo da trajetoria
    float gamma = 0.0f;           // rad: angulo da trajetoria
    float height = 0.0f;          // m acima da pista
    float verticalSpeed = 0.0f;   // m/s (informacao)
    float rotorAngle = 0.0f, rotorSpin = 0.0f;
    float runTime = 0.0f;
    float gearRetraction = 0.0f;
    float pitchRate = 0.0f, rollRate = 0.0f;   // graus/s (controlo manual)
    glm::vec3 fwd{0.0f, 0.0f, 1.0f};           // eixos do aviao no mundo: frente e "cima" (sem limites de atitude)
    glm::vec3 up{0.0f, 1.0f, 0.0f};
    glm::vec3 vel{0.0f};                        // velocidade no mundo (m/s), usada no voo manual
    bool airborne = false;
    bool manual = false;          // passa a true quando o trem esta 100% recolhido
    Phase phase = Phase::Ready;
};

// TOLD: dados previstos da descolagem (calculados sem desenhar)
struct Told { float rotationKmh, liftoffKmh, groundRoll, liftoffTime; };

// poe o aviao parado no inicio da pista, em 3 pontos
void resetAircraft(Aircraft& a, const AircraftSpec& spec);
// avanca a simulacao dt segundos (passos fixos de ate 10 ms)
void updateAircraft(Aircraft& a, float dt, const AircraftSpec& spec, const Controls& ctl = Controls());
// simula a descolagem sem desenhar, para mostrar os valores TOLD
Told predictTakeoff(const AircraftSpec& spec);
// texto da fase atual (HUD)
const char* phaseName(Phase p);
