// Modelo de voo: corrida, rotacao, subida automatica e voo manual (ponto material, unidades SI).
#include "aircraft.hpp"

#include <glm/gtc/constants.hpp>

#include <algorithm>
#include <cmath>

// a funcao de altura do terreno e definida pelo main.cpp
std::function<float(float, float)> groundHeightFn;

static void frameFromAngles(Aircraft& a);

void resetAircraft(Aircraft& a, const AircraftSpec& spec) {
    a = Aircraft();
    a.pitch = spec.groundPitch;                 // parado: aviao de trem classico, em 3 pontos
    a.pos = glm::vec3(0.0f, 0.0f, spec.runwayStartZ);
    frameFromAngles(a);
}

// roda o vetor v em torno do eixo (unitario) pelo angulo ang (rad)
static void rotateAbout(glm::vec3& v, const glm::vec3& axis, float ang) {
    float c = std::cos(ang), sn = std::sin(ang);
    v = v * c + glm::cross(axis, v) * sn + axis * (glm::dot(axis, v) * (1.0f - c));
}

// eixos a partir de rumo e picada (descolagem e subida automatica)
static void frameFromAngles(Aircraft& a) {
    const float y = glm::radians(a.yaw), p = glm::radians(a.pitch), r = glm::radians(a.roll);
    a.fwd = glm::vec3(std::sin(y) * std::cos(p), std::sin(p), std::cos(y) * std::cos(p));
    glm::vec3 u(-std::sin(y) * std::sin(p), std::cos(p), -std::cos(y) * std::sin(p));
    rotateAbout(u, a.fwd, r);
    a.up = u;
}

static void anglesFromFrame(Aircraft& a) {
    const glm::vec3 r = glm::cross(a.fwd, a.up);                 // lado direito do aviao
    a.pitch = glm::degrees(std::asin(glm::clamp(a.fwd.y, -1.0f, 1.0f)));
    a.roll = glm::degrees(std::atan2(-r.y, a.up.y));             // > 0: asa direita para baixo
    a.yaw = glm::degrees(std::atan2(a.fwd.x, a.fwd.z));
}

// Voo manual: orientacao livre em 3D (sem limites de picada ou rolamento, logo loops e tonéis).
// W/S e A/D comandam taxas de rotacao em torno dos eixos do aviao; o resto vem das forcas.
static void stepManual(Aircraft& a, float h, const AircraftSpec& s, const Controls& ctl,
                       float thrust, float cd0) {
    const float rho = 1.225f, g = 9.81f;
    const float aspect = s.wingSpan * s.wingSpan / s.wingArea;
    const float kInduced = 1.0f / (glm::pi<float>() * s.oswald * aspect);

    glm::vec3 f = a.fwd, u = a.up, r = glm::cross(f, u);
    float V = glm::length(a.vel);
    glm::vec3 vhat = V > 0.5f ? a.vel / V : f;
    const float vf = glm::dot(a.vel, f), vu = glm::dot(a.vel, u), vr = glm::dot(a.vel, r);
    const float alpha = glm::degrees(std::atan2(-vu, vf));      // incidencia (graus); sem limites de atitude
    const float beta = std::atan2(vr, std::max(std::fabs(vf), 1.0f));   // derrapagem

    // protecao de incidencia: perto da perda o comando de picada perde autoridade (o aviao nao "capota")
    float pitchCmd = ctl.pitch;
    if (pitchCmd > 0.0f)      pitchCmd *= glm::clamp((20.0f - alpha) / 6.0f, 0.0f, 1.0f);
    else if (pitchCmd < 0.0f) pitchCmd *= glm::clamp((alpha + 14.0f) / 6.0f, 0.0f, 1.0f);
    a.pitchRate += (pitchCmd * s.maxPitchRate - a.pitchRate) * std::min(1.0f, h / 0.25f);

    float rollCmd = ctl.roll * s.maxRollRate;
    const bool wingsLevelable = ctl.assist && ctl.roll == 0.0f && std::fabs(f.y) < 0.85f && a.up.y > 0.0f;
    if (wingsLevelable)                                          // estabilizador: so ate 90 graus de rolamento
        rollCmd = glm::clamp(-glm::radians(a.roll) * 1.5f * 57.2958f, -s.levelRate, s.levelRate);
    a.rollRate += (rollCmd - a.rollRate) * std::min(1.0f, h / 0.2f);

    // leme automatico: alinha o nariz com a trajetoria (voo coordenado)
    const float yawLeftRate = -2.5f * beta;                      // rad/s em torno do eixo "cima"

    rotateAbout(u, f, glm::radians(a.rollRate) * h);             // rolamento (+: asa direita para baixo)
    r = glm::cross(f, u);
    rotateAbout(f, r, glm::radians(a.pitchRate) * h);            // picada (+: nariz para cima)
    rotateAbout(u, r, glm::radians(a.pitchRate) * h);
    rotateAbout(f, u, yawLeftRate * h);
    f = glm::normalize(f);
    u = glm::normalize(u - f * glm::dot(f, u));
    a.fwd = f; a.up = u;

    // forcas
    const float q = 0.5f * rho * V * V;
    float cl = glm::clamp(s.clAlpha * (alpha + s.alphaZeroLift), -1.0f, s.clMax);
    cl *= std::max(0.0f, 1.0f - std::max(0.0f, std::fabs(alpha) - 20.0f) / 25.0f);     // perda: a sustentacao cai
    const float sa = std::sin(glm::radians(std::max(0.0f, std::fabs(alpha) - 12.0f)));
    const float drag = q * s.wingArea * (cd0 + kInduced * cl * cl + s.stallDragCoef * sa * sa);
    glm::vec3 lift(0.0f);
    glm::vec3 lDir = u - vhat * glm::dot(u, vhat);               // "cima" do aviao, perpendicular a trajetoria
    float ll = glm::length(lDir);
    if (ll > 1e-3f) lift = (lDir / ll) * (q * s.wingArea * cl);

    glm::vec3 force = f * thrust + lift - vhat * drag + glm::vec3(0.0f, -s.mass * g, 0.0f);
    a.vel += force * (h / s.mass);
    float vNew = glm::length(a.vel);
    if (vNew > s.maxSpeed) a.vel = a.vel * (s.maxSpeed / vNew);

    a.pos.x += a.vel.x * h;
    a.pos.z += a.vel.z * h;
    a.height += a.vel.y * h;

    V = glm::length(a.vel);
    a.speed = V;
    a.gamma = V > 0.5f ? std::asin(glm::clamp(a.vel.y / V, -1.0f, 1.0f)) : 0.0f;
    a.verticalSpeed = a.vel.y;
    anglesFromFrame(a);

    const float ground = groundHeightFn ? groundHeightFn(a.pos.x, a.pos.z) : 0.0f;
    if (a.height <= ground + 0.3f) {                             // contacto com o solo: fim do voo
        a.height = std::max(a.height, ground);
        a.speed = 0.0f; a.vel = glm::vec3(0.0f); a.rollRate = a.pitchRate = 0.0f;
        a.verticalSpeed = 0.0f; a.gamma = 0.0f;
        a.phase = Phase::Crashed;
    }
}

// um passo de integracao (h pequeno, ~10 ms)
static void stepAircraft(Aircraft& a, float h, const AircraftSpec& s, const Controls& ctl) {
    const float rho = 1.225f, g = 9.81f;
    const float weight = s.mass * g;
    const float aspect = s.wingSpan * s.wingSpan / s.wingArea;
    const float kInduced = 1.0f / (glm::pi<float>() * s.oswald * aspect);

    a.runTime += h;
    {   // helice: parada antes da corrida; depois acelera gradualmente
        float k = glm::clamp(a.runTime / s.propSpoolTime, 0.0f, 1.0f);
        a.rotorSpin = s.maxPropSpinRate * k * k * (3.0f - 2.0f * k);
        a.rotorAngle = std::fmod(a.rotorAngle + a.rotorSpin * h, 360.0f);
    }
    float thr = glm::clamp(a.runTime / s.throttleTime, 0.0f, 1.0f);   // o piloto avanca o acelerador
    thr = thr * thr * (3.0f - 2.0f * thr);

    const float V = a.speed;
    const float q = 0.5f * rho * V * V;
    const float thrust = thr * std::min(s.staticThrust, s.propEfficiency * s.power / std::max(V, 1.0f));
    const float cd0 = s.cd0 + (s.cdFlaps + s.cdGear) * (1.0f - a.gearRetraction);   // flaps e trem recolhem juntos
    const float gammaDeg = glm::degrees(a.gamma);

    if (a.airborne && a.manual) { stepManual(a, h, s, ctl, thrust, cd0); return; }

    // ---- comando do piloto (descolagem e subida automaticas) ----
    {
        float cmd, rate;
        if (!a.airborne) {
            if (V >= s.rotationSpeed)    { cmd = s.rotationPitch; rate = 4.5f; }
            else if (V >= s.tailUpSpeed) { cmd = 0.0f;            rate = 7.0f; }
            else                         { cmd = s.groundPitch;   rate = 7.0f; }
        } else {
            float clReq = std::min(s.clMax, weight * std::cos(a.gamma) / std::max(q * s.wingArea, 1.0f));
            float dReq = q * s.wingArea * (cd0 + kInduced * clReq * clReq);
            float aDes = glm::clamp(0.2f * (s.climbSpeed - V), 0.0f, 1.0f);   // acelera ate a velocidade de subida
            float sg = glm::clamp((thrust - dReq) / weight - aDes / g, 0.0f, 0.35f);
            float alphaReq = std::min(13.0f, clReq / s.clAlpha - s.alphaZeroLift);
            cmd = glm::degrees(std::asin(sg)) + alphaReq;
            rate = 3.5f;
        }
        cmd = glm::clamp(cmd, 0.0f, 20.0f);
        float dPitch = glm::clamp((cmd - a.pitch) / 0.5f, -rate, rate);      // resposta suavizada (tau = 0.5 s)
        a.pitch += dPitch * h;
    }

    // ---- forcas ----
    const float alpha = a.pitch - gammaDeg;
    const float cl = std::min(s.clAlpha * (alpha + s.alphaZeroLift), s.clMax);
    const float lift = q * s.wingArea * cl;
    const float drag = q * s.wingArea * (cd0 + kInduced * cl * cl);
    const float yaw = glm::radians(a.yaw);

    if (!a.airborne) {
        float normal = std::max(weight - lift, 0.0f);
        float acc = (thrust - drag - s.rollingResistance * normal) / s.mass;
        a.speed = std::max(a.speed + acc * h, 0.0f);
        a.pos += glm::vec3(std::sin(yaw), 0.0f, std::cos(yaw)) * a.speed * h;
        if (a.speed >= s.rotationSpeed && a.phase == Phase::GroundRoll) a.phase = Phase::Rotation;
        if (lift >= weight && a.speed > s.rotationSpeed) {                  // descolagem: L = P
            a.airborne = true;
            a.phase = Phase::Climb;
        }
    } else {
        float alphaRad = glm::radians(alpha);
        float acc = (thrust * std::cos(alphaRad) - drag) / s.mass - g * std::sin(a.gamma);
        float gammaDot = (lift + thrust * std::sin(alphaRad) - weight * std::cos(a.gamma)) /
                         (s.mass * std::max(V, 1.0f));
        a.speed = glm::clamp(a.speed + acc * h, 1.0f, s.maxSpeed);
        a.gamma = glm::clamp(a.gamma + gammaDot * h, glm::radians(-85.0f), glm::radians(85.0f));
        a.height += a.speed * std::sin(a.gamma) * h;
        a.pos += glm::vec3(std::sin(yaw), 0.0f, std::cos(yaw)) * a.speed * std::cos(a.gamma) * h;
        if (a.height >= s.gearRetractHeight || a.gearRetraction > 0.0f)
            a.gearRetraction = std::min(a.gearRetraction + h / s.gearRetractTime, 1.0f);
        if (a.height < 0.0f) { a.height = 0.0f; a.gamma = std::max(a.gamma, 0.0f); }
        if (a.gearRetraction >= 1.0f) {                                  // trem 100% recolhido: controlo manual
            a.manual = true;
            frameFromAngles(a);
            a.vel = glm::vec3(std::sin(yaw) * std::cos(a.gamma), std::sin(a.gamma),
                              std::cos(yaw) * std::cos(a.gamma)) * a.speed;
        }
    }
    a.verticalSpeed = a.speed * std::sin(a.gamma);
    if (!a.manual) frameFromAngles(a);
}

void updateAircraft(Aircraft& a, float dt, const AircraftSpec& spec, const Controls& ctl) {
    if (a.phase == Phase::Ready || a.phase == Phase::Crashed) return;
    const int n = std::max(1, (int)std::ceil(dt / 0.01f));                  // passos fixos <= 10 ms: estavel
    for (int i = 0; i < n; ++i) stepAircraft(a, dt / n, spec, ctl);
}

// TOLD: simula a descolagem sem desenhar, para mostrar os valores calculados.
Told predictTakeoff(const AircraftSpec& spec) {
    Aircraft a;
    resetAircraft(a, spec);
    a.phase = Phase::GroundRoll;
    float t = 0.0f;
    while (!a.airborne && t < 120.0f) { stepAircraft(a, 0.01f, spec, Controls()); t += 0.01f; }
    return {spec.rotationSpeed * 3.6f, a.speed * 3.6f, a.pos.z - spec.runwayStartZ, t};
}

const char* phaseName(Phase p) {
    switch (p) {
    case Phase::Ready: return "Pronto para descolar";
    case Phase::GroundRoll: return "Corrida de descolagem";
    case Phase::Rotation: return "Rotacao";
    case Phase::Climb: return "Subida inicial";
    case Phase::Crashed: return "CONTACTO COM O SOLO";
    default: return "Descolagem";
    }
}
