#include "runway_lights.hpp"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <map>
#include <sstream>
#include <vector>

// Luzes da pista: as posicoes e as cores vem de models/runway_lights.obj (um objeto por luz; o nome
// indica o tipo e o material a cor). Cada luz ganha um brilho (ponto luminoso) que so e desenhado a noite.
RunwayLights buildLightSprites(const std::string& objPath) {
    struct Fixture { std::string name, mat; glm::vec3 mn{1e30f}, mx{-1e30f}; };
    std::vector<glm::vec3> verts;
    std::vector<Fixture> fixtures;
    std::ifstream in(objPath);
    std::string line;
    auto trim = [](std::string t) {
        while (!t.empty() && (t.back() == '\r' || t.back() == ' ' || t.back() == '\t')) t.pop_back();
        return t;
    };
    while (std::getline(in, line)) {
        if (line.rfind("v ", 0) == 0) {
            float x, y, z;
            if (std::sscanf(line.c_str() + 2, "%f %f %f", &x, &y, &z) == 3) verts.emplace_back(x, y, z);
        } else if (line.rfind("o ", 0) == 0) {
            Fixture f; f.name = trim(line.substr(2)); fixtures.push_back(f);
        } else if (line.rfind("usemtl ", 0) == 0 && !fixtures.empty()) {
            fixtures.back().mat = trim(line.substr(7));
        } else if (line.rfind("f ", 0) == 0 && !fixtures.empty()) {
            std::istringstream ss(line.substr(2));
            std::string tok;
            while (ss >> tok) {
                int idx = std::atoi(tok.c_str());
                if (idx > 0 && (size_t)idx <= verts.size()) {
                    fixtures.back().mn = glm::min(fixtures.back().mn, verts[idx - 1]);
                    fixtures.back().mx = glm::max(fixtures.back().mx, verts[idx - 1]);
                }
            }
        }
    }
    const std::map<std::string, glm::vec3> colors = {
        {"light_white", {1.0f, 0.95f, 0.80f}}, {"light_amber", {1.0f, 0.62f, 0.05f}},
        {"light_green", {0.10f, 1.0f, 0.20f}}, {"light_red", {1.0f, 0.10f, 0.05f}}};
    std::vector<float> d;
    for (const Fixture& f : fixtures) {
        auto c = colors.find(f.mat);
        if (c == colors.end() || f.mn.x > f.mx.x) continue;
        float size = 0.5f;
        if (f.name.rfind("edge_", 0) == 0) size = 0.55f;
        else if (f.name.rfind("center_", 0) == 0) size = 0.35f;
        else if (f.name.rfind("bar_", 0) == 0) size = 0.6f;
        glm::vec3 p(0.5f * (f.mn.x + f.mx.x), f.mx.y + 0.06f, 0.5f * (f.mn.z + f.mx.z));
        d.insert(d.end(), {p.x, p.y, p.z, c->second.r, c->second.g, c->second.b, size, -1.0f});
    }
    // um ponto por luz: posicao, cor, tamanho e (reservado) fase
    RunwayLights out;
    out.count = (GLsizei)(d.size() / 8);
    GLuint vao, vbo;
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, d.size() * sizeof(float), d.data(), GL_STATIC_DRAW);
    const GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, (void*)(7 * sizeof(float)));
    glBindVertexArray(0);
    out.vao = vao;
    return out;
}

// ---- desenho dos pontos luminosos (pontos aditivos, sem escrever profundidade) ----
void drawRunwayLights(GLuint ptProg, const RunwayLights& lights, const glm::mat4& view, const glm::mat4& proj,
                      const glm::vec3& eye, float time, float night, int framebufferHeight) {
    glUseProgram(ptProg);
    glUniformMatrix4fv(glGetUniformLocation(ptProg, "uView"), 1, GL_FALSE, &view[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(ptProg, "uProj"), 1, GL_FALSE, &proj[0][0]);
    glUniform3f(glGetUniformLocation(ptProg, "uViewPos"), eye.x, eye.y, eye.z);
    glUniform1f(glGetUniformLocation(ptProg, "uTime"), time);
    glUniform1f(glGetUniformLocation(ptProg, "uNight"), night);
    glUniform1f(glGetUniformLocation(ptProg, "uSizeK"), (float)framebufferHeight * 0.866f);
    glUniform1f(glGetUniformLocation(ptProg, "uFog"), 0.00018f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glDepthMask(GL_FALSE);
    glBindVertexArray(lights.vao);
    if (night > 0.01f) glDrawArrays(GL_POINTS, 0, lights.count);    // luzes so no modo noturno
    glBindVertexArray(0);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
}
