#include "model.hpp"

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <fstream>
#include <limits>
#include <map>
#include <unordered_map>

namespace {

struct Vertex { glm::vec3 p, n; glm::vec2 uv; };
constexpr float projectedUvHorizontalScale = 0.65f;
constexpr float projectedUvVerticalScale = 0.8f;

struct Builder {
    std::vector<Vertex> verts;
    std::vector<unsigned> idx;
    std::unordered_map<unsigned long long, unsigned> seen;
};

std::string baseName(std::string s) {
    while (!s.empty() && (s.back() == ' ' || s.back() == '\r' || s.back() == '\t')) s.pop_back();
    size_t k = s.find_last_of("/\\");
    return k == std::string::npos ? s : s.substr(k + 1);
}


// Le os map_Kd diretamente do .mtl (o tinyobjloader pode cortar nomes com espacos)
std::unordered_map<std::string, std::string> readMtlTextures(const std::string& mtlPath) {
    std::unordered_map<std::string, std::string> out;
    std::ifstream f(mtlPath);
    std::string line, cur;
    while (std::getline(f, line)) {
        size_t i = line.find_first_not_of(" \t");
        if (i == std::string::npos) continue;
        line = line.substr(i);
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ' || line.back() == '\t')) line.pop_back();
        if (line.rfind("newmtl ", 0) == 0) cur = line.substr(7);
        else if (line.rfind("map_Kd ", 0) == 0 && !cur.empty()) out[cur] = line.substr(7);
    }
    return out;
}

std::string findMtlName(const std::string& objPath) {
    std::ifstream f(objPath);
    std::string l;
    for (int n = 0; n < 50 && std::getline(f, l); ++n) {
        if (l.rfind("mtllib ", 0) == 0) {
            std::string r = l.substr(7);
            while (!r.empty() && (r.back() == '\r' || r.back() == ' ')) r.pop_back();
            return r;
        }
    }
    return "";
}

GLuint loadTexture(const std::string& path, int maxSize) {
    int w = 0, h = 0, n = 0;
    stbi_set_flip_vertically_on_load(1);
    unsigned char* data = stbi_load(path.c_str(), &w, &h, &n, 4);
    if (!data) {
        std::printf("  [aviso] textura nao encontrada: %s\n", path.c_str());
        return 0;
    }
    std::vector<unsigned char> buf(data, data + (size_t)w * h * 4);
    stbi_image_free(data);

    // reduz para maxSize (media 2x2) para poupar RAM/VRAM
    while (w > maxSize || h > maxSize) {
        int nw = w / 2, nh = h / 2;
        std::vector<unsigned char> out((size_t)nw * nh * 4);
        for (int y = 0; y < nh; ++y)
            for (int x = 0; x < nw; ++x)
                for (int c = 0; c < 4; ++c) {
                    int s = buf[((size_t)(2 * y) * w + 2 * x) * 4 + c]
                          + buf[((size_t)(2 * y) * w + 2 * x + 1) * 4 + c]
                          + buf[((size_t)(2 * y + 1) * w + 2 * x) * 4 + c]
                          + buf[((size_t)(2 * y + 1) * w + 2 * x + 1) * 4 + c];
                    out[((size_t)y * nw + x) * 4 + c] = (unsigned char)(s / 4);
                }
        buf.swap(out);
        w = nw; h = nh;
    }

    GLuint t = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB8_ALPHA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, buf.data());
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    std::printf("  textura %dx%d: %s\n", w, h, path.c_str());
    return t;
}

void upload(MeshPart& part, const std::vector<Vertex>& v, const std::vector<unsigned>& idx) {
    glGenVertexArrays(1, &part.vao);
    glGenBuffers(1, &part.vbo);
    glGenBuffers(1, &part.ebo);
    glBindVertexArray(part.vao);
    glBindBuffer(GL_ARRAY_BUFFER, part.vbo);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(Vertex), v.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, part.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * sizeof(unsigned), idx.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, p));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, n));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, uv));
    glBindVertexArray(0);
    part.count = (GLsizei)idx.size();
}

} // namespace

bool Model::load(const std::string& objPath, const std::string& texDir, int maxTexSize, const StyleFn& style) {
    tinyobj::attrib_t attrib;
    std::vector<tinyobj::shape_t> shapes;
    std::vector<tinyobj::material_t> mats;
    std::string warn, err;
    std::string baseDir = objPath.substr(0, objPath.find_last_of("/\\") + 1);

    std::printf("A carregar %s ...\n", objPath.c_str());
    if (!tinyobj::LoadObj(&attrib, &shapes, &mats, &warn, &err, objPath.c_str(), baseDir.c_str(), true)) {
        std::fprintf(stderr, "Erro a ler %s: %s\n", objPath.c_str(), err.c_str());
        return false;
    }

    // bounding box
    bmin = glm::vec3(1e30f); bmax = glm::vec3(-1e30f);
    sourceVertices.clear();
    sourceVertices.reserve(attrib.vertices.size() / 3);
    for (size_t i = 0; i + 2 < attrib.vertices.size(); i += 3) {
        glm::vec3 p(attrib.vertices[i], attrib.vertices[i + 1], attrib.vertices[i + 2]);
        bmin = glm::min(bmin, p); bmax = glm::max(bmax, p);
        sourceVertices.push_back(p);
    }

    std::string mtlName = findMtlName(objPath);
    std::unordered_map<std::string, std::string> texMap;
    if (!mtlName.empty()) texMap = readMtlTextures(baseDir + mtlName);

    // materiais (+1 = material por defeito para faces sem usemtl)
    std::vector<Material> M(mats.size() + 1);
    for (size_t i = 0; i < mats.size(); ++i) {
        const auto& m = mats[i];
        M[i].name = m.name;
        M[i].kd = glm::vec3(m.diffuse[0], m.diffuse[1], m.diffuse[2]);
        M[i].ks = glm::vec3(m.specular[0], m.specular[1], m.specular[2]) * 0.35f;
        M[i].shininess = std::clamp(m.shininess, 8.0f, 128.0f);
        M[i].decal = (m.name == "white_strip");
        std::string texName = texMap.count(m.name) ? texMap[m.name] : m.diffuse_texname;
        if (!texName.empty())
            M[i].tex = loadTexture(texDir + "/" + baseName(texName), maxTexSize);
    }
    M.back().name = "default";
    M.back().kd = glm::vec3(0.8f);
    M.back().ks = glm::vec3(0.05f);
    M.back().shininess = 16.0f;
    M.back().decal = true;   // faces sem material = marcacoes da pista

    // estilos por objeto (grupo + cor); estilos iguais sao fundidos
    std::vector<ShapeStyle> styles;
    auto styleOf = [&](const std::string& name, const std::string& materialName,
                       const glm::vec3& faceCenter) -> int {
        if (!style) return -1;
        ShapeStyle st = style(name, materialName, faceCenter);
        for (size_t i = 0; i < styles.size(); ++i)
            if (styles[i].group == st.group && styles[i].hasColor == st.hasColor && styles[i].kd == st.kd &&
                styles[i].ks == st.ks && styles[i].shininess == st.shininess)
                return (int)i;
        styles.push_back(st);
        return (int)styles.size() - 1;
    };

    std::map<long long, Builder> B;   // chave = material * 4096 + (estilo + 1)
    const std::string noMaterial;
    size_t tris = 0;
    for (const auto& s : shapes) {
        size_t nf = s.mesh.indices.size() / 3;
        for (size_t f = 0; f < nf; ++f) {
            int mid = f < s.mesh.material_ids.size() ? s.mesh.material_ids[f] : -1;
            size_t slot = (mid < 0 || mid >= (int)mats.size()) ? mats.size() : (size_t)mid;
            const std::string& materialName = slot < mats.size() ? mats[slot].name : noMaterial;
            glm::vec3 p[3];
            for (int k = 0; k < 3; ++k) {
                int vi = s.mesh.indices[3 * f + k].vertex_index;
                p[k] = glm::vec3(attrib.vertices[3 * vi], attrib.vertices[3 * vi + 1], attrib.vertices[3 * vi + 2]);
            }
            int sid = styleOf(s.name, materialName, (p[0] + p[1] + p[2]) / 3.0f);
            if (sid >= 0 && styles[sid].hasColor) slot = mats.size();
            Builder& b = B[(long long)slot * 4096 + (sid + 1)];

            glm::vec3 fn = glm::cross(p[1] - p[0], p[2] - p[0]);
            float len = glm::length(fn);
            fn = len > 1e-12f ? fn / len : glm::vec3(0, 1, 0);

            for (int k = 0; k < 3; ++k) {
                const auto& ix = s.mesh.indices[3 * f + k];
                bool hasN = ix.normal_index >= 0;
                unsigned long long key = ((unsigned long long)ix.vertex_index << 42)
                                       | ((unsigned long long)(ix.texcoord_index + 1) << 21)
                                       | (unsigned long long)(ix.normal_index + 1);
                if (hasN && ix.texcoord_index >= 0) {
                    auto it = b.seen.find(key);
                    if (it != b.seen.end()) { b.idx.push_back(it->second); continue; }
                }
                Vertex v;
                v.p = p[k];
                v.n = hasN ? glm::vec3(attrib.normals[3 * ix.normal_index], attrib.normals[3 * ix.normal_index + 1],
                                       attrib.normals[3 * ix.normal_index + 2])
                           : fn;
                if (ix.texcoord_index >= 0) {
                    v.uv = glm::vec2(attrib.texcoords[2 * ix.texcoord_index],
                                     attrib.texcoords[2 * ix.texcoord_index + 1]);
                } else {
                    glm::vec3 absNormal = glm::abs(fn);
                    if (absNormal.y >= absNormal.x && absNormal.y >= absNormal.z)
                        v.uv = glm::vec2(p[k].x, p[k].z) * projectedUvHorizontalScale;
                    else if (absNormal.x >= absNormal.z)
                        v.uv = glm::vec2(p[k].z * projectedUvHorizontalScale,
                                         p[k].y * projectedUvVerticalScale);
                    else
                        v.uv = glm::vec2(p[k].x * projectedUvHorizontalScale,
                                         p[k].y * projectedUvVerticalScale);
                }
                unsigned id = (unsigned)b.verts.size();
                b.verts.push_back(v);
                if (hasN && ix.texcoord_index >= 0) b.seen[key] = id;
                b.idx.push_back(id);
            }
            ++tris;
        }
    }

    for (auto& kv : B) {
        if (kv.second.idx.empty()) continue;
        size_t slot = (size_t)(kv.first / 4096);
        int sid = (int)(kv.first % 4096) - 1;
        MeshPart part;
        part.mat = M[slot];
        if (sid >= 0) {
            const ShapeStyle& st = styles[sid];
            part.group = st.group;
            if (st.hasColor) {
                part.mat.name = "styled";
                part.mat.kd = st.kd;
                part.mat.ks = glm::vec3(st.ks);
                part.mat.shininess = st.shininess;
                part.mat.tex = 0;
                part.mat.decal = false;
            }
        }
        upload(part, kv.second.verts, kv.second.idx);
        parts.push_back(part);
    }
    std::printf("  %zu triangulos, %zu partes\n", tris, parts.size());
    return true;
}

float Model::minimumHeightAtPitch(const glm::vec3& pivot, float scale, float modelYawDegrees,
                                  float pitchDegrees) const {
    const float yaw = glm::radians(modelYawDegrees);
    const float pitch = glm::radians(pitchDegrees);
    const float cosYaw = std::cos(yaw), sinYaw = std::sin(yaw);
    const float cosPitch = std::cos(pitch), sinPitch = std::sin(pitch);
    float minimum = std::numeric_limits<float>::max();
    for (const glm::vec3& vertex : sourceVertices) {
        glm::vec3 local = (vertex - pivot) * scale;
        float zAfterYaw = -sinYaw * local.x + cosYaw * local.z;
        float yAfterPitch = cosPitch * local.y + sinPitch * zAfterYaw;
        minimum = std::min(minimum, yAfterPitch);
    }
    return minimum;
}

void Model::draw(GLuint prog, int group) const {
    GLint lKd = glGetUniformLocation(prog, "uKd");
    GLint lKs = glGetUniformLocation(prog, "uKs");
    GLint lSh = glGetUniformLocation(prog, "uShininess");
    GLint lHas = glGetUniformLocation(prog, "uHasTex");
    for (const auto& p : parts) {
        if (group >= 0 && p.group != group) continue;
        glUniform3f(lKd, p.mat.kd.x, p.mat.kd.y, p.mat.kd.z);
        glUniform3f(lKs, p.mat.ks.x, p.mat.ks.y, p.mat.ks.z);
        glUniform1f(lSh, p.mat.shininess);
        glUniform1i(lHas, p.mat.tex != 0);
        if (p.mat.tex) { glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, p.mat.tex); }
        // fator: inclinacao da superficie (camara rasante); unidades: resolucao do buffer de profundidade
        if (p.mat.decal) { glEnable(GL_POLYGON_OFFSET_FILL); glPolygonOffset(-3.0f, -12.0f); }
        glBindVertexArray(p.vao);
        glDrawElements(GL_TRIANGLES, p.count, GL_UNSIGNED_INT, nullptr);
        if (p.mat.decal) glDisable(GL_POLYGON_OFFSET_FILL);
    }
    glBindVertexArray(0);
}

void Model::destroy() {
    for (auto& p : parts) {
        glDeleteVertexArrays(1, &p.vao);
        glDeleteBuffers(1, &p.vbo);
        glDeleteBuffers(1, &p.ebo);
        if (p.mat.tex) glDeleteTextures(1, &p.mat.tex);
    }
    parts.clear();
    sourceVertices.clear();
}
