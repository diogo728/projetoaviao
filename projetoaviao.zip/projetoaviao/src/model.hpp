#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <functional>
#include <string>
#include <vector>

struct Material {
    std::string name;
    glm::vec3 kd{0.8f};      // cor difusa (Kd do .mtl)
    glm::vec3 ks{0.1f};      // cor especular (Ks do .mtl)
    float shininess = 32.0f; // Ns do .mtl
    GLuint tex = 0;          // textura de cor (map_Kd), 0 = sem textura
    bool decal = false;      // desenhado com polygon offset (marcacoes da pista)
};

struct MeshPart {            // uma parte da malha
    GLuint vao = 0, vbo = 0, ebo = 0;
    GLsizei count = 0;
    int group = 0;           // grupo de animacao (0 = corpo; o resto define-o o programa)
    Material mat;
};

// Estilo opcional por objeto/material: grupo de animacao e cor.
struct ShapeStyle {
    int group = 0;
    bool hasColor = false;
    glm::vec3 kd{0.8f};
    float ks = 0.2f;
    float shininess = 32.0f;
};
using StyleFn = std::function<ShapeStyle(const std::string& shapeName, const std::string& materialName,
                                         const glm::vec3& faceCenter)>;

class Model {
public:
    std::vector<MeshPart> parts;
    std::vector<glm::vec3> sourceVertices;
    glm::vec3 bmin{0.0f}, bmax{0.0f};

    // Carrega .obj (triangula) + .mtl. Texturas procuradas pelo NOME do ficheiro em texDir.
    // 'style' (opcional) decide grupo e cor a partir do objeto e material.
    bool load(const std::string& objPath, const std::string& texDir, int maxTexSize = 2048,
              const StyleFn& style = nullptr);
    float minimumHeightAtPitch(const glm::vec3& pivot, float scale, float modelYawDegrees,
                               float pitchDegrees) const;
    void draw(GLuint program, int group = -1) const;   // group -1 = tudo
    void destroy();
};
