// Ceu: lista de skyboxes (skybox/skies.txt), cubemap, ciclo dia/noite e desenho.
#pragma once
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <string>
#include <vector>

struct SkyInfo {                       // uma linha de skybox/skies.txt
    std::string name, cat, title;
    glm::vec3 lightCol{1.0f}, lightDir{0.0f, 1.0f, 0.0f}, fog{0.6f, 0.75f, 0.9f};
    float ambient = 0.28f, night = 0.0f;
};

// Estado do ceu (antes vivia dentro do App)
struct Sky {
    std::vector<SkyInfo> skies;                        // lido de skybox/skies.txt
    int idx = -1;                                      // -1 = ceu de reserva (sem skybox)
    GLuint cube = 0;                                   // cubemap do ceu atual
    GLuint prog = 0;                                   // programa do ceu (SkyVertexShader/SkyFragmentShader)
    GLuint emptyVao = 0;                               // o ceu usa gl_VertexID, mas o core profile exige um VAO
    glm::vec3 lightOff{400.0f, 700.0f, 300.0f};        // posicao da luz relativa ao aviao
    float night = 0.0f;                                // 0 = dia, 1 = noite (suavizado; controla o brilho das luzes da pista)
    float nightTarget = 0.0f;
    std::string root;                                  // pasta skybox/
};

// Valores de iluminacao derivados do ceu, usados tambem pela cena (neblina, luz e ambiente)
struct SkyLook {
    glm::vec3 horizon, lightCol;
    float ambient;
};

// carrega a lista de ceus e escolhe o primeiro; usa o ceu de reserva se nao houver skybox
void initSky(Sky& sky, const std::string& skyRoot, GLuint skyProg);
void selectSky(Sky& sky, int idx);
void toggleDayNight(Sky& sky);                         // alterna entre os dois primeiros ceus (tecla M)
void updateNight(Sky& sky, float dt);                  // transicao suave dia <-> noite
SkyLook skyLook(const Sky& sky);
const char* skyTitle(const Sky& sky);                  // nome do ceu para o HUD
void drawSky(const Sky& sky, const SkyLook& look, const glm::mat4& view, const glm::mat4& proj,
             const glm::vec3& eye);
void destroySky(Sky& sky);
