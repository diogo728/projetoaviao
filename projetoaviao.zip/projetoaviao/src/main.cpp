// Simulador de descolagem do Kawasaki Ki-61 Hien - 14350 Computer Graphics
// OpenGL 3.3 core, GLFW, GLEW, GLM. Phong por fragmento com luz pontual. Linux.
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/constants.hpp>

#include <algorithm>
#include <cmath>
#include <map>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include "model.hpp"
#include "common/shader.hpp"
#include "stb_image.h"      // so as declaracoes (a implementacao esta em model.cpp)

// ----------------------------------------------------------------------------
// Pista, em metros. O modelo runway_short.obj e um troco central da pista
// original: 3200 unidades de comprimento e 113.85 de largura de asfalto.
// Uma escala uniforme leva o asfalto a 45 m (largura da pista 05/23 do
// aeroporto da Madeira, LPMA), o que da um troco de cerca de 1265 m.
// ----------------------------------------------------------------------------
namespace cfg {
constexpr float RUNWAY_MODEL_LENGTH = 3200.0f;
constexpr float RUNWAY_MODEL_WIDTH = 113.852722f;
constexpr float RUNWAY_WIDTH = 45.0f;
constexpr float RUNWAY_SCALE = RUNWAY_WIDTH / RUNWAY_MODEL_WIDTH;
constexpr float RUNWAY_LENGTH = RUNWAY_MODEL_LENGTH * RUNWAY_SCALE;
constexpr float RUNWAY_HALF = RUNWAY_LENGTH * 0.5f;
constexpr float START_SETBACK = 30.0f;          // o aviao arranca 30 m depois da cabeceira
constexpr float EDGE_LIGHT_X = RUNWAY_WIDTH * 0.5f - 0.5f;   // luzes de bordo a 0.5 m do limite do asfalto
}

// Luzes da pista: as posicoes e as cores vem de models/runway_lights.obj (um objeto por luz; o nome
// indica o tipo e o material a cor). Cada luz ganha um brilho (ponto luminoso) que so e desenhado a noite.
static GLuint buildLightSprites(const std::string& objPath, GLsizei& count) {
    struct Fixture { std::string name, mat; glm::vec3 mn{1e30f}, mx{-1e30f}; };
    std::vector<glm::vec3> verts;
    std::vector<Fixture> fixtures;
    std::ifstream in(objPath);
    std::string line;
    auto trim = [](std::string t) {
        while (!t.empty() && (t.back() == '\r' || t.back() == ' ' || t.back() == '\t')) t.pop_back();
        return t;
    };
    while (std::getline(in, line)) {
        if (line.rfind("v ", 0) == 0) {
            float x, y, z;
            if (std::sscanf(line.c_str() + 2, "%f %f %f", &x, &y, &z) == 3) verts.emplace_back(x, y, z);
        } else if (line.rfind("o ", 0) == 0) {
            Fixture f; f.name = trim(line.substr(2)); fixtures.push_back(f);
        } else if (line.rfind("usemtl ", 0) == 0 && !fixtures.empty()) {
            fixtures.back().mat = trim(line.substr(7));
        } else if (line.rfind("f ", 0) == 0 && !fixtures.empty()) {
            std::istringstream ss(line.substr(2));
            std::string tok;
            while (ss >> tok) {
                int idx = std::atoi(tok.c_str());
                if (idx > 0 && (size_t)idx <= verts.size()) {
                    fixtures.back().mn = glm::min(fixtures.back().mn, verts[idx - 1]);
                    fixtures.back().mx = glm::max(fixtures.back().mx, verts[idx - 1]);
                }
            }
        }
    }
    const std::map<std::string, glm::vec3> colors = {
        {"light_white", {1.0f, 0.95f, 0.80f}}, {"light_amber", {1.0f, 0.62f, 0.05f}},
        {"light_green", {0.10f, 1.0f, 0.20f}}, {"light_red", {1.0f, 0.10f, 0.05f}}};
    std::vector<float> d;
    for (const Fixture& f : fixtures) {
        auto c = colors.find(f.mat);
        if (c == colors.end() || f.mn.x > f.mx.x) continue;
        float size = 0.5f;
        if (f.name.rfind("edge_", 0) == 0) size = 0.55f;
        else if (f.name.rfind("center_", 0) == 0) size = 0.35f;
        else if (f.name.rfind("bar_", 0) == 0) size = 0.6f;
        glm::vec3 p(0.5f * (f.mn.x + f.mx.x), f.mx.y + 0.06f, 0.5f * (f.mn.z + f.mx.z));
        d.insert(d.end(), {p.x, p.y, p.z, c->second.r, c->second.g, c->second.b, size, -1.0f});
    }
    count = (GLsizei)(d.size() / 8);
    GLuint vao, vbo;
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, d.size() * sizeof(float), d.data(), GL_STATIC_DRAW);
    const GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(3); glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, (void*)(7 * sizeof(float)));
    glBindVertexArray(0);
    return vao;
}

// ----------------------------------------------------------------------------
// Estado do aviao e simulacao da descolagem
// ----------------------------------------------------------------------------
enum class Phase { Ready, GroundRoll, Rotation, Climb, Crashed };

// ----------------------------------------------------------------------------
// Modelo de voo (ponto material no plano vertical), em unidades SI.
// Valores publicados do Ki-61-I: comprimento 8.94 m, envergadura 12.0 m,
// area alar 20 m2, massa 3470 kg, potencia 1175 hp, subida inicial 15.2 m/s.
// Estimativas: coeficientes aerodinamicos, tracao estatica, resistencia ao
// rolamento e velocidades de manobra do piloto (ver README).
// ----------------------------------------------------------------------------
struct AircraftSpec {
    const char* name = "Kawasaki Ki-61 Hien";
    const char* modelFile = "kawasaki.obj";
    float length = 8.94f;               // m
    float modelYaw = 180.0f;            // orientacao do modelo OBJ (graus)
    float mass = 3470.0f;               // kg
    float wingArea = 20.0f;             // m2
    float wingSpan = 12.0f;             // m
    float power = 1175.0f * 745.7f;     // W (Ha-40, potencia de descolagem)
    float staticThrust = 11000.0f;      // N (limite da tracao a baixa velocidade)
    float propEfficiency = 0.80f;
    float cd0 = 0.026f, cdGear = 0.015f, cdFlaps = 0.010f, oswald = 0.80f;
    float clAlpha = 0.09f;              // por grau (asa de alongamento 7.2)
    float alphaZeroLift = 3.0f;         // graus (incidencia + curvatura)
    float clMax = 1.55f;                // com flaps de descolagem (Vs ~ 150 km/h)
    float rollingResistance = 0.03f;
    float throttleTime = 3.0f;          // s ate a potencia maxima
    float tailUpSpeed = 95.0f / 3.6f;   // m/s: a cauda sobe
    float rotationSpeed = 140.0f / 3.6f;// m/s: o piloto puxa o nariz
    float groundPitch = 13.1f;          // graus: atitude de 3 pontos (da geometria do modelo)
    float rotationPitch = 11.0f;        // graus: atitude comandada na rotacao
    float climbSpeed = 230.0f / 3.6f;   // m/s: velocidade de subida (< limite de 250 km/h com trem)
    float gearRetractHeight = 10.0f;    // m
    float gearRetractTime = 6.0f;       // s
    float propSpoolTime = 5.0f;         // s ate a helice atingir a rotacao maxima
    float maxPropSpinRate = 1800.0f;    // graus/s (limite visual)
    // controlo manual (apos a recolha completa do trem)
    float maxPitchRate = 15.0f;         // graus/s com a pancada de manche a fundo
    float maxRollRate = 70.0f;          // graus/s (Ki-61 a ~230 km/h; estimativa)
    float levelRate = 15.0f;            // graus/s: nivelamento das asas sem comando
    float stallDragCoef = 1.2f;         // resistencia da asa em perda (placa plana ~ 1.2 sin^2)
    float maxSpeed = 750.0f / 3.6f;     // m/s: limite de velocidade em picada (estimativa)
    float runwayStartZ = -cfg::RUNWAY_HALF + cfg::START_SETBACK;
};

// comandos do piloto, de -1 a 1: pitch > 0 = nariz para cima; roll > 0 = asa direita para baixo
struct Controls {
    float pitch = 0.0f, roll = 0.0f;
    bool assist = true;     // estabilizador: nivela as asas (so ate 90 graus de rolamento) sem comando de rolamento
};

// altura do terreno sob o aviao (definida pelo programa); sem ela o solo e plano em y = 0
static std::function<float(float, float)> groundHeightFn;
static const AircraftSpec aircraftSpec{};

struct Aircraft {
    glm::vec3 pos{0.0f};          // pos.y e calculado no desenho (altura + contacto com o solo)
    float yaw = 0.0f, pitch = 0.0f, roll = 0.0f;
    float speed = 0.0f;           // m/s, ao longo da trajetoria
    float gamma = 0.0f;           // rad: angulo da trajetoria
    float height = 0.0f;          // m acima da pista
    float verticalSpeed = 0.0f;   // m/s (informacao)
    float rotorAngle = 0.0f, rotorSpin = 0.0f;
    float runTime = 0.0f;
    float gearRetraction = 0.0f;
    float pitchRate = 0.0f, rollRate = 0.0f;   // graus/s (controlo manual)
    glm::vec3 fwd{0.0f, 0.0f, 1.0f};           // eixos do aviao no mundo: frente e "cima" (sem limites de atitude)
    glm::vec3 up{0.0f, 1.0f, 0.0f};
    glm::vec3 vel{0.0f};                        // velocidade no mundo (m/s), usada no voo manual
    bool airborne = false;
    bool manual = false;          // passa a true quando o trem esta 100% recolhido
    Phase phase = Phase::Ready;
};

static void frameFromAngles(Aircraft& a);

static void resetAircraft(Aircraft& a, const AircraftSpec& spec) {
    a = Aircraft();
    a.pitch = spec.groundPitch;                 // parado: aviao de trem classico, em 3 pontos
    a.pos = glm::vec3(0.0f, 0.0f, spec.runwayStartZ);
    frameFromAngles(a);
}

// roda o vetor v em torno do eixo (unitario) pelo angulo ang (rad)
static void rotateAbout(glm::vec3& v, const glm::vec3& axis, float ang) {
    float c = std::cos(ang), sn = std::sin(ang);
    v = v * c + glm::cross(axis, v) * sn + axis * (glm::dot(axis, v) * (1.0f - c));
}

// eixos a partir de rumo e picada (descolagem e subida automatica)
static void frameFromAngles(Aircraft& a) {
    const float y = glm::radians(a.yaw), p = glm::radians(a.pitch), r = glm::radians(a.roll);
    a.fwd = glm::vec3(std::sin(y) * std::cos(p), std::sin(p), std::cos(y) * std::cos(p));
    glm::vec3 u(-std::sin(y) * std::sin(p), std::cos(p), -std::cos(y) * std::sin(p));
    rotateAbout(u, a.fwd, r);
    a.up = u;
}

static void anglesFromFrame(Aircraft& a) {
    const glm::vec3 r = glm::cross(a.fwd, a.up);                 // lado direito do aviao
    a.pitch = glm::degrees(std::asin(glm::clamp(a.fwd.y, -1.0f, 1.0f)));
    a.roll = glm::degrees(std::atan2(-r.y, a.up.y));             // > 0: asa direita para baixo
    a.yaw = glm::degrees(std::atan2(a.fwd.x, a.fwd.z));
}

// Voo manual: orientacao livre em 3D (sem limites de picada ou rolamento, logo loops e tonéis).
// W/S e A/D comandam taxas de rotacao em torno dos eixos do aviao; o resto vem das forcas.
static void stepManual(Aircraft& a, float h, const AircraftSpec& s, const Controls& ctl,
                       float thrust, float cd0) {
    const float rho = 1.225f, g = 9.81f;
    const float aspect = s.wingSpan * s.wingSpan / s.wingArea;
    const float kInduced = 1.0f / (glm::pi<float>() * s.oswald * aspect);

    glm::vec3 f = a.fwd, u = a.up, r = glm::cross(f, u);
    float V = glm::length(a.vel);
    glm::vec3 vhat = V > 0.5f ? a.vel / V : f;
    const float vf = glm::dot(a.vel, f), vu = glm::dot(a.vel, u), vr = glm::dot(a.vel, r);
    const float alpha = glm::degrees(std::atan2(-vu, vf));      // incidencia (graus); sem limites de atitude
    const float beta = std::atan2(vr, std::max(std::fabs(vf), 1.0f));   // derrapagem

    // protecao de incidencia: perto da perda o comando de picada perde autoridade (o aviao nao "capota")
    float pitchCmd = ctl.pitch;
    if (pitchCmd > 0.0f)      pitchCmd *= glm::clamp((20.0f - alpha) / 6.0f, 0.0f, 1.0f);
    else if (pitchCmd < 0.0f) pitchCmd *= glm::clamp((alpha + 14.0f) / 6.0f, 0.0f, 1.0f);
    a.pitchRate += (pitchCmd * s.maxPitchRate - a.pitchRate) * std::min(1.0f, h / 0.25f);

    float rollCmd = ctl.roll * s.maxRollRate;
    const bool wingsLevelable = ctl.assist && ctl.roll == 0.0f && std::fabs(f.y) < 0.85f && a.up.y > 0.0f;
    if (wingsLevelable)                                          // estabilizador: so ate 90 graus de rolamento
        rollCmd = glm::clamp(-glm::radians(a.roll) * 1.5f * 57.2958f, -s.levelRate, s.levelRate);
    a.rollRate += (rollCmd - a.rollRate) * std::min(1.0f, h / 0.2f);

    // leme automatico: alinha o nariz com a trajetoria (voo coordenado)
    const float yawLeftRate = -2.5f * beta;                      // rad/s em torno do eixo "cima"

    rotateAbout(u, f, glm::radians(a.rollRate) * h);             // rolamento (+: asa direita para baixo)
    r = glm::cross(f, u);
    rotateAbout(f, r, glm::radians(a.pitchRate) * h);            // picada (+: nariz para cima)
    rotateAbout(u, r, glm::radians(a.pitchRate) * h);
    rotateAbout(f, u, yawLeftRate * h);
    f = glm::normalize(f);
    u = glm::normalize(u - f * glm::dot(f, u));
    a.fwd = f; a.up = u;

    // forcas
    const float q = 0.5f * rho * V * V;
    float cl = glm::clamp(s.clAlpha * (alpha + s.alphaZeroLift), -1.0f, s.clMax);
    cl *= std::max(0.0f, 1.0f - std::max(0.0f, std::fabs(alpha) - 20.0f) / 25.0f);     // perda: a sustentacao cai
    const float sa = std::sin(glm::radians(std::max(0.0f, std::fabs(alpha) - 12.0f)));
    const float drag = q * s.wingArea * (cd0 + kInduced * cl * cl + s.stallDragCoef * sa * sa);
    glm::vec3 lift(0.0f);
    glm::vec3 lDir = u - vhat * glm::dot(u, vhat);               // "cima" do aviao, perpendicular a trajetoria
    float ll = glm::length(lDir);
    if (ll > 1e-3f) lift = (lDir / ll) * (q * s.wingArea * cl);

    glm::vec3 force = f * thrust + lift - vhat * drag + glm::vec3(0.0f, -s.mass * g, 0.0f);
    a.vel += force * (h / s.mass);
    float vNew = glm::length(a.vel);
    if (vNew > s.maxSpeed) a.vel = a.vel * (s.maxSpeed / vNew);

    a.pos.x += a.vel.x * h;
    a.pos.z += a.vel.z * h;
    a.height += a.vel.y * h;

    V = glm::length(a.vel);
    a.speed = V;
    a.gamma = V > 0.5f ? std::asin(glm::clamp(a.vel.y / V, -1.0f, 1.0f)) : 0.0f;
    a.verticalSpeed = a.vel.y;
    anglesFromFrame(a);

    const float ground = groundHeightFn ? groundHeightFn(a.pos.x, a.pos.z) : 0.0f;
    if (a.height <= ground + 0.3f) {                             // contacto com o solo: fim do voo
        a.height = std::max(a.height, ground);
        a.speed = 0.0f; a.vel = glm::vec3(0.0f); a.rollRate = a.pitchRate = 0.0f;
        a.verticalSpeed = 0.0f; a.gamma = 0.0f;
        a.phase = Phase::Crashed;
    }
}

// um passo de integracao (h pequeno, ~10 ms)
static void stepAircraft(Aircraft& a, float h, const AircraftSpec& s, const Controls& ctl) {
    const float rho = 1.225f, g = 9.81f;
    const float weight = s.mass * g;
    const float aspect = s.wingSpan * s.wingSpan / s.wingArea;
    const float kInduced = 1.0f / (glm::pi<float>() * s.oswald * aspect);

    a.runTime += h;
    {   // helice: parada antes da corrida; depois acelera gradualmente
        float k = glm::clamp(a.runTime / s.propSpoolTime, 0.0f, 1.0f);
        a.rotorSpin = s.maxPropSpinRate * k * k * (3.0f - 2.0f * k);
        a.rotorAngle = std::fmod(a.rotorAngle + a.rotorSpin * h, 360.0f);
    }
    float thr = glm::clamp(a.runTime / s.throttleTime, 0.0f, 1.0f);   // o piloto avanca o acelerador
    thr = thr * thr * (3.0f - 2.0f * thr);

    const float V = a.speed;
    const float q = 0.5f * rho * V * V;
    const float thrust = thr * std::min(s.staticThrust, s.propEfficiency * s.power / std::max(V, 1.0f));
    const float cd0 = s.cd0 + (s.cdFlaps + s.cdGear) * (1.0f - a.gearRetraction);   // flaps e trem recolhem juntos
    const float gammaDeg = glm::degrees(a.gamma);

    if (a.airborne && a.manual) { stepManual(a, h, s, ctl, thrust, cd0); return; }

    // ---- comando do piloto (descolagem e subida automaticas) ----
    {
        float cmd, rate;
        if (!a.airborne) {
            if (V >= s.rotationSpeed)    { cmd = s.rotationPitch; rate = 4.5f; }
            else if (V >= s.tailUpSpeed) { cmd = 0.0f;            rate = 7.0f; }
            else                         { cmd = s.groundPitch;   rate = 7.0f; }
        } else {
            float clReq = std::min(s.clMax, weight * std::cos(a.gamma) / std::max(q * s.wingArea, 1.0f));
            float dReq = q * s.wingArea * (cd0 + kInduced * clReq * clReq);
            float aDes = glm::clamp(0.2f * (s.climbSpeed - V), 0.0f, 1.0f);   // acelera ate a velocidade de subida
            float sg = glm::clamp((thrust - dReq) / weight - aDes / g, 0.0f, 0.35f);
            float alphaReq = std::min(13.0f, clReq / s.clAlpha - s.alphaZeroLift);
            cmd = glm::degrees(std::asin(sg)) + alphaReq;
            rate = 3.5f;
        }
        cmd = glm::clamp(cmd, 0.0f, 20.0f);
        float dPitch = glm::clamp((cmd - a.pitch) / 0.5f, -rate, rate);      // resposta suavizada (tau = 0.5 s)
        a.pitch += dPitch * h;
    }

    // ---- forcas ----
    const float alpha = a.pitch - gammaDeg;
    const float cl = std::min(s.clAlpha * (alpha + s.alphaZeroLift), s.clMax);
    const float lift = q * s.wingArea * cl;
    const float drag = q * s.wingArea * (cd0 + kInduced * cl * cl);
    const float yaw = glm::radians(a.yaw);

    if (!a.airborne) {
        float normal = std::max(weight - lift, 0.0f);
        float acc = (thrust - drag - s.rollingResistance * normal) / s.mass;
        a.speed = std::max(a.speed + acc * h, 0.0f);
        a.pos += glm::vec3(std::sin(yaw), 0.0f, std::cos(yaw)) * a.speed * h;
        if (a.speed >= s.rotationSpeed && a.phase == Phase::GroundRoll) a.phase = Phase::Rotation;
        if (lift >= weight && a.speed > s.rotationSpeed) {                  // descolagem: L = P
            a.airborne = true;
            a.phase = Phase::Climb;
        }
    } else {
        float alphaRad = glm::radians(alpha);
        float acc = (thrust * std::cos(alphaRad) - drag) / s.mass - g * std::sin(a.gamma);
        float gammaDot = (lift + thrust * std::sin(alphaRad) - weight * std::cos(a.gamma)) /
                         (s.mass * std::max(V, 1.0f));
        a.speed = glm::clamp(a.speed + acc * h, 1.0f, s.maxSpeed);
        a.gamma = glm::clamp(a.gamma + gammaDot * h, glm::radians(-85.0f), glm::radians(85.0f));
        a.height += a.speed * std::sin(a.gamma) * h;
        a.pos += glm::vec3(std::sin(yaw), 0.0f, std::cos(yaw)) * a.speed * std::cos(a.gamma) * h;
        if (a.height >= s.gearRetractHeight || a.gearRetraction > 0.0f)
            a.gearRetraction = std::min(a.gearRetraction + h / s.gearRetractTime, 1.0f);
        if (a.height < 0.0f) { a.height = 0.0f; a.gamma = std::max(a.gamma, 0.0f); }
        if (a.gearRetraction >= 1.0f) {                                  // trem 100% recolhido: controlo manual
            a.manual = true;
            frameFromAngles(a);
            a.vel = glm::vec3(std::sin(yaw) * std::cos(a.gamma), std::sin(a.gamma),
                              std::cos(yaw) * std::cos(a.gamma)) * a.speed;
        }
    }
    a.verticalSpeed = a.speed * std::sin(a.gamma);
    if (!a.manual) frameFromAngles(a);
}

static void updateAircraft(Aircraft& a, float dt, const AircraftSpec& spec, const Controls& ctl = Controls()) {
    if (a.phase == Phase::Ready || a.phase == Phase::Crashed) return;
    const int n = std::max(1, (int)std::ceil(dt / 0.01f));                  // passos fixos <= 10 ms: estavel
    for (int i = 0; i < n; ++i) stepAircraft(a, dt / n, spec, ctl);
}

// TOLD: simula a descolagem sem desenhar, para mostrar os valores calculados.
struct Told { float rotationKmh, liftoffKmh, groundRoll, liftoffTime; };
static Told predictTakeoff(const AircraftSpec& spec) {
    Aircraft a;
    resetAircraft(a, spec);
    a.phase = Phase::GroundRoll;
    float t = 0.0f;
    while (!a.airborne && t < 120.0f) { stepAircraft(a, 0.01f, spec, Controls()); t += 0.01f; }
    return {spec.rotationSpeed * 3.6f, a.speed * 3.6f, a.pos.z - spec.runwayStartZ, t};
}

static const char* phaseName(Phase p) {
    switch (p) {
    case Phase::Ready: return "Pronto para descolar";
    case Phase::GroundRoll: return "Corrida de descolagem";
    case Phase::Rotation: return "Rotacao";
    case Phase::Climb: return "Subida inicial";
    case Phase::Crashed: return "CONTACTO COM O SOLO";
    default: return "Descolagem";
    }
}

// ----------------------------------------------------------------------------
// Aplicacao (estado global simples, acedido pelos callbacks do GLFW)
// ----------------------------------------------------------------------------
struct SkyInfo {                       // uma linha de skybox/skies.txt
    std::string name, cat, title;
    glm::vec3 lightCol{1.0f}, lightDir{0.0f, 1.0f, 0.0f}, fog{0.6f, 0.75f, 0.9f};
    float ambient = 0.28f, night = 0.0f;
};

struct App {
    Aircraft ac;
    bool startRequested = false;
    float planeScale = 1.0f;
    glm::vec3 planePivot{0.0f};
    float night = 0.0f;                                // 0 = dia, 1 = noite (suavizado; controla o brilho das luzes da pista)
    float nightTarget = 0.0f;
    std::vector<SkyInfo> skies;                        // lido de skybox/skies.txt
    int skyIdx = -1;                                   // -1 = ceu de reserva (sem skybox)
    GLuint cube = 0;
    int camMode = 1;                                   // 1 seguimento, 2 camera na asa
    bool camInit = false;                              // foco suavizado da camara de seguimento
    glm::vec3 camF{0.0f, 0.0f, 1.0f}, camU{0.0f, 1.0f, 0.0f};   // eixos suavizados da camara de seguimento
    bool assist = true;                                // estabilizador (tecla L)
    Told told{};
    float chaseYaw = 0.0f, chasePitch = 14.0f, chaseDist = 22.25f; // graus / metros
    glm::vec3 lightOff{400.0f, 700.0f, 300.0f};
    double lastX = 0, lastY = 0;
    bool firstMouse = true, leftDown = false;
    int fbW = 1280, fbH = 720;
} app;


static std::string skyRoot;

static bool loadSkyList(const std::string& file, std::vector<SkyInfo>& out) {
    std::ifstream f(file);
    if (!f) return false;
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream ss(line);
        SkyInfo s;
        ss >> s.name >> s.cat >> s.lightCol.r >> s.lightCol.g >> s.lightCol.b >> s.ambient
           >> s.lightDir.x >> s.lightDir.y >> s.lightDir.z >> s.fog.r >> s.fog.g >> s.fog.b >> s.night;
        if (!ss) continue;
        std::getline(ss, s.title);
        size_t i = s.title.find_first_not_of(" \t");
        s.title = i == std::string::npos ? s.name : s.title.substr(i);
        while (!s.title.empty() && (s.title.back() == '\r' || s.title.back() == ' ')) s.title.pop_back();
        out.push_back(s);
    }
    return !out.empty();
}

static GLuint loadCubemap(const std::string& dir) {
    const char* face[6] = {"px", "nx", "py", "ny", "pz", "nz"};     // ordem GL_TEXTURE_CUBE_MAP_POSITIVE_X + i
    GLuint t = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_CUBE_MAP, t);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    stbi_set_flip_vertically_on_load(0);
    for (int i = 0; i < 6; ++i) {
        std::string path = dir + "/" + face[i] + ".jpg";
        int w = 0, h = 0, n = 0;
        unsigned char* d = stbi_load(path.c_str(), &w, &h, &n, 3);
        if (!d) { std::fprintf(stderr, "[aviso] nao abri %s\n", path.c_str()); glDeleteTextures(1, &t); return 0; }
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_SRGB8, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, d);
        stbi_image_free(d);
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    return t;
}

static void selectSky(int idx) {
    if (idx < 0 || idx >= (int)app.skies.size()) return;
    GLuint t = loadCubemap(skyRoot + "/" + app.skies[idx].name);
    if (!t) return;
    if (app.cube) glDeleteTextures(1, &app.cube);
    app.cube = t;
    app.skyIdx = idx;
    const SkyInfo& s = app.skies[idx];
    app.lightOff = glm::normalize(s.lightDir) * 850.0f;      // a luz da cena vem de onde esta o sol/lua da imagem
    app.nightTarget = s.night;
    std::printf("Ceu: %s (%s)\n", s.title.c_str(), s.name.c_str());
}

static void toggleDayNight() {
    if (app.skies.size() < 2) {
        std::fprintf(stderr, "Sao necessarios os ceus diurno e noturno para alternar com M.\n");
        return;
    }
    selectSky(app.skyIdx == 0 ? 1 : 0);
}

static void keyCb(GLFWwindow* w, int key, int, int action, int) {
    if (action != GLFW_PRESS) return;
    switch (key) {
    case GLFW_KEY_ESCAPE: glfwSetWindowShouldClose(w, GLFW_TRUE); break;
    case GLFW_KEY_M:                                       // modo de arranque: so antes da descolagem
        if (app.ac.phase == Phase::Ready && !app.startRequested) toggleDayNight();
        break;
    case GLFW_KEY_ENTER: case GLFW_KEY_KP_ENTER:
        if (app.ac.phase == Phase::Ready) app.startRequested = true;
        break;
    case GLFW_KEY_R:
        resetAircraft(app.ac, aircraftSpec);
        app.startRequested = false;
        app.camInit = false;
        app.chaseYaw = 0.0f;
        app.chasePitch = 14.0f;
        app.chaseDist = std::max(8.0f, aircraftSpec.length * 2.5f);
        break;
    case GLFW_KEY_1: app.camMode = 1; break;
    case GLFW_KEY_2: app.camMode = 2; break;
    case GLFW_KEY_L: app.assist = !app.assist; break;
    default: break;
    }
}

static void mouseButtonCb(GLFWwindow*, int button, int action, int) {
    if (button == GLFW_MOUSE_BUTTON_LEFT) app.leftDown = (action == GLFW_PRESS);
}

static void cursorCb(GLFWwindow*, double x, double y) {
    if (app.firstMouse) { app.lastX = x; app.lastY = y; app.firstMouse = false; }
    float dx = (float)(x - app.lastX), dy = (float)(y - app.lastY);
    app.lastX = x; app.lastY = y;
    if (app.leftDown && app.camMode == 1) {                   // orbita a camara de seguimento
        app.chaseYaw -= dx * 0.3f;
        app.chasePitch = glm::clamp(app.chasePitch + dy * 0.3f, 2.0f, 85.0f);
    }
}

static void scrollCb(GLFWwindow*, double, double yoff) {
    if (app.camMode == 1)
        app.chaseDist = glm::clamp(app.chaseDist * (1.0f - 0.1f * (float)yoff), 8.0f, 400.0f);
}

static void resizeCb(GLFWwindow*, int w, int h) { app.fbW = std::max(w, 1); app.fbH = std::max(h, 1); glViewport(0, 0, app.fbW, app.fbH); }

static ShapeStyle aircraftStyle(const std::string& name, const std::string&,
                                const glm::vec3& faceCenter) {
    ShapeStyle style;
    const float absX = std::abs(faceCenter.x);
    const bool separateGearMesh =
        name.rfind("Cylinder.", 0) == 0 || name.rfind("Cube.", 0) == 0 ||
        name.rfind("BezierCurve.", 0) == 0 || name.rfind("Plane.10", 0) == 0 ||
        name == "Pipe.001";
    if (separateGearMesh && absX > 0.45f && absX < 1.15f &&
        faceCenter.y < 0.66f && faceCenter.z > -1.0f && faceCenter.z < -0.55f) {
        style.group = faceCenter.x < 0.0f ? 5 : 6;
        return style;
    }

    // Roda de cauda: o garfo e o eixo sao pecas pequenas separadas, junto ao plano de simetria.
    if ((name.rfind("Cylinder.", 0) == 0 || name.rfind("Cube.", 0) == 0) && absX < 0.12f &&
        faceCenter.z > 1.2f && faceCenter.z < 1.5f && faceCenter.y < 0.7f) {
        style.group = 7;
        return style;
    }

    // O objeto exportado junta a hélice (z < -1.2) e partes do trem.
    if (name == "Plane.007_Plane.008") {
        if (faceCenter.z < -1.2f) style.group = 4;
        else style.group = faceCenter.x < 0.0f ? 8 : 9;
    } else if (name == "Plane.005_Plane.015") {
        style.group = faceCenter.x < 0.0f ? 5 : 6;
    } else if (name == "Plane.009_Plane.027") {
        style.group = 7;
    }
    return style;
}

static bool loadAircraft(Model& model, const std::string& root) {
    StyleFn style = [](const std::string& name, const std::string& material,
                       const glm::vec3& faceCenter) {
        return aircraftStyle(name, material, faceCenter);
    };
    if (!model.load(root + "/models/" + aircraftSpec.modelFile, root + "/textures", 2048, style))
        return false;

    const float modelLength = model.bmax.z - model.bmin.z;
    if (modelLength <= 0.0f) {
        std::fprintf(stderr, "Comprimento invalido no modelo %s\n", aircraftSpec.modelFile);
        model.destroy();
        return false;
    }

    app.planeScale = aircraftSpec.length / modelLength;
    app.planePivot = glm::vec3((model.bmin.x + model.bmax.x) * 0.5f,
                               model.bmin.y,
                               (model.bmin.z + model.bmax.z) * 0.5f);
    app.chaseDist = aircraftSpec.length * 2.5f;
    std::printf("Aviao: %s (escala %.4f)\n", aircraftSpec.name, app.planeScale);
    return true;
}

// ----------------------------------------------------------------------------
int main() {
    if (!glfwInit()) { std::fprintf(stderr, "glfwInit falhou\n"); return 1; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 2);
    glfwWindowHint(GLFW_DEPTH_BITS, 24);   // profundidade de 24 bits: o polygon offset das marcacoes depende disto

    GLFWwindow* win = glfwCreateWindow(app.fbW, app.fbH, "Simulador de Descolagem", nullptr, nullptr);
    if (!win) { std::fprintf(stderr, "Nao foi possivel criar contexto OpenGL 3.3 core\n"); glfwTerminate(); return 1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);
    glfwSetKeyCallback(win, keyCb);
    glfwSetMouseButtonCallback(win, mouseButtonCb);
    glfwSetCursorPosCallback(win, cursorCb);
    glfwSetScrollCallback(win, scrollCb);
    glfwSetFramebufferSizeCallback(win, resizeCb);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) { std::fprintf(stderr, "glewInit falhou\n"); return 1; }
    std::printf("OpenGL %s | %s\n", glGetString(GL_VERSION), glGetString(GL_RENDERER));

    glfwGetFramebufferSize(win, &app.fbW, &app.fbH);
    glViewport(0, 0, app.fbW, app.fbH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);

    const std::string root = ASSET_DIR;
    Model runway, plane, terrain, hangars, lightFixtures;
    if (!runway.load(root + "/models/runway_short.obj", root + "/textures")) return 1;
    if (!loadAircraft(plane, root)) { runway.destroy(); return 1; }
    if (!terrain.load(root + "/models/terrain.obj", root + "/textures")) {
        runway.destroy(); plane.destroy(); return 1;
    }
    if (!hangars.load(root + "/models/hangars.obj", root + "/textures") ||
        !lightFixtures.load(root + "/models/runway_lights.obj", root + "/textures")) return 1;
    // para o contacto com o solo so interessam os vertices baixos do aviao (rodas, cauda): poupa ~85% do calculo
    plane.sourceVertices.erase(std::remove_if(plane.sourceVertices.begin(), plane.sourceVertices.end(),
                                              [](const glm::vec3& v) { return v.y > 0.75f; }),
                               plane.sourceVertices.end());
    // grelha de alturas do terreno (301x301, passo 120 m) para a deteccao de contacto com o solo
    std::vector<float> terrainY;
    {
        const int TN = 301;
        if (terrain.sourceVertices.size() == (size_t)TN * TN) {
            terrainY.resize((size_t)TN * TN);
            for (size_t i = 0; i < terrainY.size(); ++i) terrainY[i] = terrain.sourceVertices[i].y;
        }
        groundHeightFn = [&terrainY, TN](float x, float z) -> float {
            if (std::fabs(x) < cfg::RUNWAY_WIDTH * 0.5f + 1.5f && std::fabs(z) < cfg::RUNWAY_HALF)
                return 0.0f;                                            // pista
            if (terrainY.empty()) return 0.0f;
            const float step = 120.0f, org = -18000.0f;
            float fx = glm::clamp((x - org) / step, 0.0f, (float)(TN - 1) - 0.001f);
            float fz = glm::clamp((z - org) / step, 0.0f, (float)(TN - 1) - 0.001f);
            int ix = (int)fx, iz = (int)fz;
            float tx = fx - ix, tz = fz - iz;
            auto H = [&](int i, int j) { return terrainY[(size_t)j * TN + i]; };
            float h0 = H(ix, iz) * (1 - tx) + H(ix + 1, iz) * tx;
            float h1 = H(ix, iz + 1) * (1 - tx) + H(ix + 1, iz + 1) * tx;
            return h0 * (1 - tz) + h1 * tz;
        };
    }
    const std::string shaderRoot = root + "/shaders";
    GLuint prog = LoadShaders(shaderRoot + "/SimpleVertexShader.vertexshader",
                              shaderRoot + "/SimpleFragmentShader.fragmentshader");
    GLuint skyProg = LoadShaders(shaderRoot + "/SkyVertexShader.vertexshader",
                                 shaderRoot + "/SkyFragmentShader.fragmentshader");
    GLuint ptProg = LoadShaders(shaderRoot + "/PointVertexShader.vertexshader",
                                shaderRoot + "/PointFragmentShader.fragmentshader");
    if (!prog || !skyProg || !ptProg) {
        if (prog) glDeleteProgram(prog);
        if (skyProg) glDeleteProgram(skyProg);
        if (ptProg) glDeleteProgram(ptProg);
        runway.destroy(); plane.destroy(); terrain.destroy(); hangars.destroy(); lightFixtures.destroy();
        glfwDestroyWindow(win);
        glfwTerminate();
        return 1;
    }
    glUseProgram(prog);
    glUniform1i(glGetUniformLocation(prog, "uTex"), 0);

    skyRoot = root + "/skybox";
    if (loadSkyList(skyRoot + "/skies.txt", app.skies)) {
        std::printf("Skybox: %zu ceus em %s\n", app.skies.size(), skyRoot.c_str());
        selectSky(0);
    } else {
        std::printf("(sem pasta skybox: a usar o ceu de reserva)\n");
    }

    GLuint emptyVao = 0;
    glGenVertexArrays(1, &emptyVao);                  // o ceu usa gl_VertexID, mas o core profile exige um VAO
    GLsizei lightCount = 0;
    GLuint lightVao = buildLightSprites(root + "/models/runway_lights.obj", lightCount);
    glEnable(GL_PROGRAM_POINT_SIZE);
    std::printf("  luzes da pista: %d\n", (int)lightCount);

    resetAircraft(app.ac, aircraftSpec);
    app.told = predictTakeoff(aircraftSpec);
    std::printf("TOLD: rotacao %.0f km/h, descolagem %.0f km/h, corrida %.0f m (%.1f s)\n",
                app.told.rotationKmh, app.told.liftoffKmh, app.told.groundRoll, app.told.liftoffTime);
    double prev = glfwGetTime(), titleT = 0.0;

    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();
        if (app.startRequested) {
            resetAircraft(app.ac, aircraftSpec);
            app.camInit = false;
            app.ac.phase = Phase::GroundRoll;
            app.startRequested = false;
        }

        double now = glfwGetTime();
        float dt = (float)std::min(now - prev, 0.1);
        prev = now;

        {   // transicao dia <-> noite (2 s)
            float tgt = app.nightTarget;
            if (app.night < tgt) app.night = std::min(app.night + dt * 0.5f, tgt);
            else                 app.night = std::max(app.night - dt * 0.5f, tgt);
        }
        Controls ctl;   // W/S: picada (W nariz para baixo, S para cima); A/D: rolamento (A asa esquerda para baixo)
        if (glfwGetKey(win, GLFW_KEY_W) == GLFW_PRESS) ctl.pitch -= 1.0f;
        if (glfwGetKey(win, GLFW_KEY_S) == GLFW_PRESS) ctl.pitch += 1.0f;
        if (glfwGetKey(win, GLFW_KEY_A) == GLFW_PRESS) ctl.roll -= 1.0f;
        if (glfwGetKey(win, GLFW_KEY_D) == GLFW_PRESS) ctl.roll += 1.0f;
        ctl.assist = app.assist;
        updateAircraft(app.ac, dt, aircraftSpec, ctl);
        float airBlend = 0.0f;
        glm::vec3 planePivotUse = app.planePivot;
        {   // as rodas tocam na pista no solo; no ar mantem-se a altura sobre a pista
            float minimum = 0.0f;
            if (app.ac.height < 16.0f)        // acima disto o contacto com o solo ja nao entra na posicao
                minimum = plane.minimumHeightAtPitch(app.planePivot, app.planeScale, aircraftSpec.modelYaw,
                                                     app.ac.pitch);
            // no solo roda-se em torno das rodas; em voo, em torno do centro do aviao (transicao nos primeiros 15 m)
            airBlend = glm::smoothstep(0.0f, 15.0f, app.ac.height);
            planePivotUse = glm::mix(app.planePivot, glm::vec3(app.planePivot.x, 0.5f * (plane.bmin.y + plane.bmax.y),
                                                               app.planePivot.z), airBlend);
            float yGround = app.ac.height - minimum + 0.01f;
            float yAir = app.ac.height + (0.5f * (plane.bmin.y + plane.bmax.y) - app.planePivot.y) * app.planeScale;
            app.ac.pos.y = glm::mix(yGround, yAir, airBlend);
        }

        glm::mat4 M(1.0f);
        M = glm::translate(M, app.ac.pos);
        {   // orientacao livre: colunas = eixos locais x (esquerda), y (cima), z (frente) no mundo
            glm::mat4 R(1.0f);
            R[0] = glm::vec4(glm::cross(app.ac.up, app.ac.fwd), 0.0f);
            R[1] = glm::vec4(app.ac.up, 0.0f);
            R[2] = glm::vec4(app.ac.fwd, 0.0f);
            M = M * R;
        }
        M = glm::rotate(M, glm::radians(aircraftSpec.modelYaw), glm::vec3(0, 1, 0));
        M = glm::scale(M, glm::vec3(app.planeScale));
        M = glm::translate(M, -planePivotUse);

        // ---- camara ----
        // camara de seguimento: horizonte sempre nivelado, atras do rumo do aviao (como no inicio da descolagem).
        // Em picadas verticais ou de pernas para o ar o rumo nao e fiavel: a camara mantem o ultimo rumo.
        glm::vec3 wantF = app.camF, wantU = glm::vec3(0.0f, 1.0f, 0.0f);
        {
            glm::vec3 h(app.ac.fwd.x, 0.0f, app.ac.fwd.z);
            if (glm::length(h) > 0.35f && app.ac.up.y > 0.0f) wantF = glm::normalize(h);
        }
        const bool camFirst = !app.camInit;
        if (camFirst) { app.camF = wantF; app.camU = wantU; app.camInit = true; }
        {
            float k = 1.0f - std::exp(-4.0f * dt);
            glm::vec3 f = app.camF + (wantF - app.camF) * k;
            f = glm::length(f) > 1e-4f ? glm::normalize(f) : wantF;
            glm::vec3 u = app.camU + (wantU - app.camU) * k;
            u = u - f * glm::dot(f, u);
            u = glm::length(u) > 1e-4f ? glm::normalize(u) : wantU;
            app.camF = f; app.camU = u;
        }
        glm::vec3 target = app.ac.pos + app.camU * 2.5f, eye;
        glm::vec3 up(0.0f, 1.0f, 0.0f);
        glm::mat4 view;
        if (app.camMode == 1) {       // a orbita (rato) e centrada no proprio aviao; so o rumo da camara e suavizado
            float y = glm::radians(app.chaseYaw), p = glm::radians(app.chasePitch);
            glm::vec3 camR = glm::cross(app.camF, app.camU);
            eye = target + app.chaseDist * (std::cos(p) * std::sin(y) * camR + std::sin(p) * app.camU -
                                            std::cos(p) * std::cos(y) * app.camF);
            view = glm::lookAt(eye, target, app.camU);
        } else if (app.camMode == 2) {
            const glm::vec3 localEye(1.15f, 0.95f, 0.15f);
            const glm::vec3 localFocus(1.0f, 0.80f, -4.0f);
            eye = glm::vec3(M * glm::vec4(localEye, 1.0f));
            target = glm::vec3(M * glm::vec4(localFocus, 1.0f));
            up = glm::normalize(glm::mat3(M) * up);
            view = glm::lookAt(eye, target, up);
        }
        glm::mat4 proj = glm::perspective(glm::radians(60.0f),
                                         (float)app.fbW / (float)app.fbH, 1.0f, 20000.0f);

        // ---- desenho ----
        const float nt = app.night;
        auto lin = [](const glm::vec3& g) { return glm::pow(g, glm::vec3(2.2f)); };
        const bool haveSky = app.skyIdx >= 0;
        glm::vec3 horizon, zenith, lightCol;
        float ambient;
        if (haveSky) {                                         // valores vindos de skybox/skies.txt
            const SkyInfo& si = app.skies[app.skyIdx];
            horizon = lin(si.fog); zenith = horizon; lightCol = si.lightCol; ambient = si.ambient;
        } else {                                               // reserva: ceu simples sem skybox
            horizon  = glm::mix(lin(glm::vec3(0.70f, 0.82f, 0.95f)), lin(glm::vec3(0.03f, 0.04f, 0.08f)), nt);
            zenith   = glm::mix(lin(glm::vec3(0.18f, 0.40f, 0.82f)), lin(glm::vec3(0.002f, 0.004f, 0.02f)), nt);
            lightCol = glm::mix(glm::vec3(1.0f, 0.97f, 0.90f), glm::vec3(0.22f, 0.26f, 0.42f), nt);
            ambient  = glm::mix(0.28f, 0.10f, nt);
        }
        glm::vec3 sunDir = glm::normalize(app.lightOff);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // ---- ceu ----
        glDisable(GL_DEPTH_TEST);
        glUseProgram(skyProg);
        glm::mat4 invVP = glm::inverse(proj * view);
        glUniformMatrix4fv(glGetUniformLocation(skyProg, "uInvVP"), 1, GL_FALSE, &invVP[0][0]);
        glUniform3f(glGetUniformLocation(skyProg, "uCamPos"), eye.x, eye.y, eye.z);
        glUniform3f(glGetUniformLocation(skyProg, "uSunDir"), sunDir.x, sunDir.y, sunDir.z);
        glUniform3f(glGetUniformLocation(skyProg, "uHorizon"), horizon.r, horizon.g, horizon.b);
        glUniform3f(glGetUniformLocation(skyProg, "uZenith"), zenith.r, zenith.g, zenith.b);
        glUniform1f(glGetUniformLocation(skyProg, "uNight"), nt);
        glUniform1i(glGetUniformLocation(skyProg, "uUseCube"), haveSky ? 1 : 0);
        glUniform1i(glGetUniformLocation(skyProg, "uCube"), 1);
        if (haveSky) { glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_CUBE_MAP, app.cube); glActiveTexture(GL_TEXTURE0); }
        glBindVertexArray(emptyVao);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glEnable(GL_DEPTH_TEST);

        // ---- cena ----
        glUseProgram(prog);
        glm::vec3 lightPos = app.ac.pos + app.lightOff;
        glUniformMatrix4fv(glGetUniformLocation(prog, "uView"), 1, GL_FALSE, &view[0][0]);
        glUniformMatrix4fv(glGetUniformLocation(prog, "uProj"), 1, GL_FALSE, &proj[0][0]);
        glUniform3f(glGetUniformLocation(prog, "uLightPos"), lightPos.x, lightPos.y, lightPos.z);
        glUniform3f(glGetUniformLocation(prog, "uLightColor"), lightCol.r, lightCol.g, lightCol.b);
        glUniform3f(glGetUniformLocation(prog, "uViewPos"), eye.x, eye.y, eye.z);
        glUniform3f(glGetUniformLocation(prog, "uSky"), horizon.r, horizon.g, horizon.b);   // neblina = cor do horizonte
        glUniform1f(glGetUniformLocation(prog, "uAmbient"), ambient);
        glUniform1f(glGetUniformLocation(prog, "uFog"), 0.00018f);

        GLint locM = glGetUniformLocation(prog, "uModel"), locN = glGetUniformLocation(prog, "uNormalMat");
        auto setModel = [&](const glm::mat4& M) {
            glm::mat3 nm = glm::transpose(glm::inverse(glm::mat3(M)));
            glUniformMatrix4fv(locM, 1, GL_FALSE, &M[0][0]);
            glUniformMatrix3fv(locN, 1, GL_FALSE, &nm[0][0]);
        };

        setModel(glm::mat4(1.0f));
        terrain.draw(prog);
        hangars.draw(prog);
        lightFixtures.draw(prog);
        setModel(glm::scale(glm::mat4(1.0f), glm::vec3(cfg::RUNWAY_SCALE)));
        runway.draw(prog);

        setModel(M);
        plane.draw(prog, 0);
        const float gearT = glm::clamp(app.ac.gearRetraction, 0.0f, 1.0f);
        const float gearBlend = gearT * gearT * (3.0f - 2.0f * gearT);
        // Ki-61: trem principal de via larga (4 m) que recolhe PARA DENTRO. Cada perna roda
        // ~90 graus em torno de um eixo longitudinal no topo da perna, junto a asa, e a roda
        // fica deitada no interior da asa. A roda de cauda (versoes iniciais) roda para a
        // frente, para dentro da fuselagem. Pivos em coordenadas do modelo OBJ.
        auto drawGearPart = [&](int group, const glm::vec3& pivot, float angle, const glm::vec3& axis) {
            glm::mat4 G = glm::translate(M, pivot);
            G = glm::rotate(G, angle, axis);
            G = glm::translate(G, -pivot);
            setModel(G);
            plane.draw(prog, group);
        };
        if (gearBlend < 1.0f) {
            const float swing = glm::half_pi<float>() * gearBlend;
            const glm::vec3 legL(-0.77f, 0.60f, -0.83f), legR(0.77f, 0.60f, -0.83f);   // 0.60 = a meio da espessura da asa: a roda fica dentro dela
            const glm::vec3 tailPivot(0.0f, 0.80f, 1.40f), zAxis(0, 0, 1), xAxis(1, 0, 0);
            drawGearPart(5, legL, +swing, zAxis);      // esquerda: o fundo da perna roda para +X (para dentro)
            drawGearPart(8, legL, +swing, zAxis);
            drawGearPart(6, legR, -swing, zAxis);      // direita: para -X (para dentro)
            drawGearPart(9, legR, -swing, zAxis);
            drawGearPart(7, tailPivot, +swing, xAxis); // cauda: o fundo roda para -Z do modelo (frente)
        }
        const glm::vec3 propellerPivot(0.0f, 0.74f, -1.56f);
        glm::mat4 propellerModel = glm::translate(M, propellerPivot);
        propellerModel = glm::rotate(propellerModel, glm::radians(app.ac.rotorAngle),
                                     glm::vec3(0.0f, 0.0f, 1.0f));
        propellerModel = glm::translate(propellerModel, -propellerPivot);
        setModel(propellerModel);
        plane.draw(prog, 4);

        // ---- luzes da pista (pontos aditivos, sem escrever profundidade) ----
        glUseProgram(ptProg);
        glUniformMatrix4fv(glGetUniformLocation(ptProg, "uView"), 1, GL_FALSE, &view[0][0]);
        glUniformMatrix4fv(glGetUniformLocation(ptProg, "uProj"), 1, GL_FALSE, &proj[0][0]);
        glUniform3f(glGetUniformLocation(ptProg, "uViewPos"), eye.x, eye.y, eye.z);
        glUniform1f(glGetUniformLocation(ptProg, "uTime"), (float)now);
        glUniform1f(glGetUniformLocation(ptProg, "uNight"), nt);
        glUniform1f(glGetUniformLocation(ptProg, "uSizeK"), (float)app.fbH * 0.866f);
        glUniform1f(glGetUniformLocation(ptProg, "uFog"), 0.00018f);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        glDepthMask(GL_FALSE);
        glBindVertexArray(lightVao);
        if (nt > 0.01f) glDrawArrays(GL_POINTS, 0, lightCount);    // luzes so no modo noturno
        glBindVertexArray(0);
        glDepthMask(GL_TRUE);
        glDisable(GL_BLEND);

        glfwSwapBuffers(win);

        // HUD na barra de titulo
        if (now - titleT > 0.25) {
            titleT = now;
            char t[320];
            const char* skyTitle = app.skyIdx >= 0 ? app.skies[app.skyIdx].title.c_str() : "ceu";
            if (app.ac.phase == Phase::Ready) {
                std::snprintf(t, sizeof t,
                              "PRE-VOO | Ki-61 | Vr %.0f km/h, descola ~%.0f km/h, corrida ~%.0f m | %s | M dia/noite | Enter descolar | 1/2 camera",
                              app.told.rotationKmh, app.told.liftoffKmh, app.told.groundRoll, skyTitle);
            } else {
                const char* label = (app.ac.manual && app.ac.phase != Phase::Crashed)
                                        ? (app.assist ? "MANUAL: W/S picada, A/D rolamento, L estabilizador ON"
                                                      : "MANUAL: W/S picada, A/D rolamento, L estabilizador OFF")
                                        : phaseName(app.ac.phase);
                std::snprintf(t, sizeof t,
                              "%s | alt %.0f m | vel %.0f km/h | subida %.1f m/s | trem %.0f%% | picada %.0f° rol %.0f° | cam %d | R reiniciar | %s",
                              label, app.ac.height, app.ac.speed * 3.6f, app.ac.verticalSpeed,
                              app.ac.gearRetraction * 100.0f, app.ac.pitch, app.ac.roll, app.camMode, skyTitle);
            }
            glfwSetWindowTitle(win, t);
        }
    }

    runway.destroy(); plane.destroy(); terrain.destroy(); hangars.destroy(); lightFixtures.destroy();
    if (app.cube) glDeleteTextures(1, &app.cube);
    glDeleteProgram(prog); glDeleteProgram(skyProg); glDeleteProgram(ptProg);
    glfwDestroyWindow(win);
    glfwTerminate();
    return 0;
}
