// Simulador de descolagem do Kawasaki Ki-61 Hien - 14350 Computer Graphics
// OpenGL 3.3 core, GLFW, GLEW, GLM. Phong por fragmento com luz pontual. Linux.
//
// Organizacao: main.cpp (janela, entrada, ciclo principal), aircraft (fisica), sky (ceu e dia/noite),
// runway_lights (luzes da pista), render (camaras, desenho do aviao, HUD), model (malhas .obj).
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>

#include "aircraft.hpp"
#include "config.hpp"
#include "model.hpp"
#include "render.hpp"
#include "runway_lights.hpp"
#include "sky.hpp"
#include "common/shader.hpp"

// Fallback caso o CMake não defina ASSET_DIR durante a análise estática (IntelliSense)
#ifndef ASSET_DIR
#define ASSET_DIR "../assets"
#endif

// parametros do aviao (so de leitura); a fisica e o desenho recebem-nos por referencia
static const AircraftSpec aircraftSpec{};

// ----------------------------------------------------------------------------
// Aplicacao (estado global simples, acedido pelos callbacks do GLFW)
// ----------------------------------------------------------------------------
struct App {
    Aircraft ac;
    bool startRequested = false;
    float planeScale = 1.0f;
    glm::vec3 planePivot{0.0f};
    Sky sky;                                           // ceu, ciclo dia/noite e luz (ver sky.hpp)
    Camera cam;                                        // camaras 1 (seguimento) e 2 (asa) (ver render.hpp)
    bool assist = true;                                // estabilizador (tecla L)
    Told told{};
    double lastX = 0, lastY = 0;
    bool firstMouse = true, leftDown = false;
    int fbW = 1280, fbH = 720;
} app;

// ---- callbacks do GLFW ----
static void keyCb(GLFWwindow* w, int key, int, int action, int) {
    if (action != GLFW_PRESS) return;
    switch (key) {
    case GLFW_KEY_ESCAPE: glfwSetWindowShouldClose(w, GLFW_TRUE); break;
    case GLFW_KEY_M:                                       // modo de arranque: so antes da descolagem
        if (app.ac.phase == Phase::Ready && !app.startRequested) toggleDayNight(app.sky);
        break;
    case GLFW_KEY_ENTER: case GLFW_KEY_KP_ENTER:
        if (app.ac.phase == Phase::Ready) app.startRequested = true;
        break;
    case GLFW_KEY_R:
        resetAircraft(app.ac, aircraftSpec);
        app.startRequested = false;
        app.cam.init = false;
        app.cam.yaw = 0.0f;
        app.cam.pitch = 14.0f;
        app.cam.dist = std::max(8.0f, aircraftSpec.length * 2.5f);
        break;
    case GLFW_KEY_1: app.cam.mode = 1; break;
    case GLFW_KEY_2: app.cam.mode = 2; break;
    case GLFW_KEY_L: app.assist = !app.assist; break;
    default: break;
    }
}

static void mouseButtonCb(GLFWwindow*, int button, int action, int) {
    if (button == GLFW_MOUSE_BUTTON_LEFT) app.leftDown = (action == GLFW_PRESS);
}

static void cursorCb(GLFWwindow*, double x, double y) {
    if (app.firstMouse) { app.lastX = x; app.lastY = y; app.firstMouse = false; }
    float dx = (float)(x - app.lastX), dy = (float)(y - app.lastY);
    app.lastX = x; app.lastY = y;
    if (app.leftDown && app.cam.mode == 1) {                  // orbita a camara de seguimento
        app.cam.yaw -= dx * 0.3f;
        app.cam.pitch = glm::clamp(app.cam.pitch + dy * 0.3f, 2.0f, 85.0f);
    }
}

static void scrollCb(GLFWwindow*, double, double yoff) {
    if (app.cam.mode == 1)
        app.cam.dist = glm::clamp(app.cam.dist * (1.0f - 0.1f * (float)yoff), 8.0f, 400.0f);
}

static void resizeCb(GLFWwindow*, int w, int h) { app.fbW = std::max(w, 1); app.fbH = std::max(h, 1); glViewport(0, 0, app.fbW, app.fbH); }

// ---- aviao: grupos de animacao do OBJ (helice, pernas do trem, roda de cauda) ----
static ShapeStyle aircraftStyle(const std::string& name, const std::string&,
                                const glm::vec3& faceCenter) {
    ShapeStyle style;
    const float absX = std::abs(faceCenter.x);
    const bool separateGearMesh =
        name.rfind("Cylinder.", 0) == 0 || name.rfind("Cube.", 0) == 0 ||
        name.rfind("BezierCurve.", 0) == 0 || name.rfind("Plane.10", 0) == 0 ||
        name == "Pipe.001";
    if (separateGearMesh && absX > 0.45f && absX < 1.15f &&
        faceCenter.y < 0.66f && faceCenter.z > -1.0f && faceCenter.z < -0.55f) {
        style.group = faceCenter.x < 0.0f ? 5 : 6;
        return style;
    }

    // Roda de cauda: o garfo e o eixo sao pecas pequenas separadas, junto ao plano de simetria.
    if ((name.rfind("Cylinder.", 0) == 0 || name.rfind("Cube.", 0) == 0) && absX < 0.12f &&
        faceCenter.z > 1.2f && faceCenter.z < 1.5f && faceCenter.y < 0.7f) {
        style.group = 7;
        return style;
    }

    // O objeto exportado junta a hélice (z < -1.2) e partes do trem.
    if (name == "Plane.007_Plane.008") {
        if (faceCenter.z < -1.2f) style.group = 4;
        else style.group = faceCenter.x < 0.0f ? 8 : 9;
    } else if (name == "Plane.005_Plane.015") {
        style.group = faceCenter.x < 0.0f ? 5 : 6;
    } else if (name == "Plane.009_Plane.027") {
        style.group = 7;
    }
    return style;
}

static bool loadAircraft(Model& model, const std::string& root) {
    StyleFn style = [](const std::string& name, const std::string& material,
                       const glm::vec3& faceCenter) {
        return aircraftStyle(name, material, faceCenter);
    };
    if (!model.load(root + "/models/" + aircraftSpec.modelFile, root + "/textures", 2048, style))
        return false;

    const float modelLength = model.bmax.z - model.bmin.z;
    if (modelLength <= 0.0f) {
        std::fprintf(stderr, "Comprimento invalido no modelo %s\n", aircraftSpec.modelFile);
        model.destroy();
        return false;
    }

    app.planeScale = aircraftSpec.length / modelLength;
    app.planePivot = glm::vec3((model.bmin.x + model.bmax.x) * 0.5f,
                               model.bmin.y,
                               (model.bmin.z + model.bmax.z) * 0.5f);
    app.cam.dist = aircraftSpec.length * 2.5f;
    std::printf("Aviao: %s (escala %.4f)\n", aircraftSpec.name, app.planeScale);
    return true;
}

// ---- terreno: grelha de alturas (301x301, passo 120 m) para a deteccao de contacto com o solo ----
static std::function<float(float, float)> makeGroundHeight(const Model& terrain) {
    const int TN = 301;
    std::vector<float> terrainY;
    if (terrain.sourceVertices.size() == (size_t)TN * TN) {
        terrainY.resize((size_t)TN * TN);
        for (size_t i = 0; i < terrainY.size(); ++i) terrainY[i] = terrain.sourceVertices[i].y;
    }
    return [terrainY, TN](float x, float z) -> float {
        if (std::fabs(x) < cfg::RUNWAY_WIDTH * 0.5f + 1.5f && std::fabs(z) < cfg::RUNWAY_HALF)
            return 0.0f;                                            // pista
        if (terrainY.empty()) return 0.0f;
        const float step = 120.0f, org = -18000.0f;
        float fx = glm::clamp((x - org) / step, 0.0f, (float)(TN - 1) - 0.001f);
        float fz = glm::clamp((z - org) / step, 0.0f, (float)(TN - 1) - 0.001f);
        int ix = (int)fx, iz = (int)fz;
        float tx = fx - ix, tz = fz - iz;
        auto H = [&](int i, int j) { return terrainY[(size_t)j * TN + i]; };
        float h0 = H(ix, iz) * (1 - tx) + H(ix + 1, iz) * tx;
        float h1 = H(ix, iz + 1) * (1 - tx) + H(ix + 1, iz + 1) * tx;
        return h0 * (1 - tz) + h1 * tz;
    };
}

// ----------------------------------------------------------------------------
int main() {
    if (!glfwInit()) { std::fprintf(stderr, "glfwInit falhou\n"); return 1; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 2);
    glfwWindowHint(GLFW_DEPTH_BITS, 24);   // profundidade de 24 bits: o polygon offset das marcacoes depende disto

    GLFWwindow* win = glfwCreateWindow(app.fbW, app.fbH, "Simulador de Descolagem", nullptr, nullptr);
    if (!win) { std::fprintf(stderr, "Nao foi possivel criar contexto OpenGL 3.3 core\n"); glfwTerminate(); return 1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);
    glfwSetKeyCallback(win, keyCb);
    glfwSetMouseButtonCallback(win, mouseButtonCb);
    glfwSetCursorPosCallback(win, cursorCb);
    glfwSetScrollCallback(win, scrollCb);
    glfwSetFramebufferSizeCallback(win, resizeCb);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) { std::fprintf(stderr, "glewInit falhou\n"); return 1; }
    std::printf("OpenGL %s | %s\n", glGetString(GL_VERSION), glGetString(GL_RENDERER));

    glfwGetFramebufferSize(win, &app.fbW, &app.fbH);
    glViewport(0, 0, app.fbW, app.fbH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);


    // ---- recursos: malhas ----
    const std::string root = ASSET_DIR;
    Model runway, plane, terrain, hangars, lightFixtures;
    if (!runway.load(root + "/models/runway_short.obj", root + "/textures")) return 1;
    if (!loadAircraft(plane, root)) { runway.destroy(); return 1; }
    if (!terrain.load(root + "/models/terrain.obj", root + "/textures")) {
        runway.destroy(); plane.destroy(); return 1;
    }
    if (!hangars.load(root + "/models/hangars.obj", root + "/textures") ||
        !lightFixtures.load(root + "/models/runway_lights.obj", root + "/textures")) return 1;
    // para o contacto com o solo so interessam os vertices baixos do aviao (rodas, cauda): poupa ~85% do calculo
    plane.sourceVertices.erase(std::remove_if(plane.sourceVertices.begin(), plane.sourceVertices.end(),
                                              [](const glm::vec3& v) { return v.y > 0.75f; }),
                               plane.sourceVertices.end());
    groundHeightFn = makeGroundHeight(terrain);

    // ---- shaders (com .c_str() adicionado para conversão segura de std::string para const char*) ----
    const std::string shaderRoot = root + "/shaders";
    GLuint prog = LoadShaders((shaderRoot + "/SimpleVertexShader.vertexshader").c_str(),
                              (shaderRoot + "/SimpleFragmentShader.fragmentshader").c_str());
    GLuint skyProg = LoadShaders((shaderRoot + "/SkyVertexShader.vertexshader").c_str(),
                                 (shaderRoot + "/SkyFragmentShader.fragmentshader").c_str());
    GLuint ptProg = LoadShaders((shaderRoot + "/PointVertexShader.vertexshader").c_str(),
                                (shaderRoot + "/PointFragmentShader.fragmentshader").c_str());
    if (!prog || !skyProg || !ptProg) {
        if (prog) glDeleteProgram(prog);
        if (skyProg) glDeleteProgram(skyProg);
        if (ptProg) glDeleteProgram(ptProg);
        runway.destroy(); plane.destroy(); terrain.destroy(); hangars.destroy(); lightFixtures.destroy();
        glfwDestroyWindow(win);
        glfwTerminate();
        return 1;
    }
    glUseProgram(prog);
    glUniform1i(glGetUniformLocation(prog, "uTex"), 0);


    // ---- ceu, luzes da pista e TOLD ----
    initSky(app.sky, root + "/skybox", skyProg);
    RunwayLights lights = buildLightSprites(root + "/models/runway_lights.obj");
    glEnable(GL_PROGRAM_POINT_SIZE);
    std::printf("  luzes da pista: %d\n", (int)lights.count);

    resetAircraft(app.ac, aircraftSpec);
    app.told = predictTakeoff(aircraftSpec);
    std::printf("TOLD: rotacao %.0f km/h, descolagem %.0f km/h, corrida %.0f m (%.1f s)\n",
                app.told.rotationKmh, app.told.liftoffKmh, app.told.groundRoll, app.told.liftoffTime);
    double prev = glfwGetTime(), titleT = 0.0;

    // ---- ciclo principal: entrada, fisica, camara, ceu, cena, luzes, HUD ----
    while (!glfwWindowShouldClose(win)) {
        glfwPollEvents();
        if (app.startRequested) {
            resetAircraft(app.ac, aircraftSpec);
            app.cam.init = false;
            app.ac.phase = Phase::GroundRoll;
            app.startRequested = false;
        }

        double now = glfwGetTime();
        float dt = (float)std::min(now - prev, 0.1);
        prev = now;

        updateNight(app.sky, dt);
        Controls ctl;   // W/S: picada (W nariz para baixo, S para cima); A/D: rolamento (A asa esquerda para baixo)
        if (glfwGetKey(win, GLFW_KEY_W) == GLFW_PRESS) ctl.pitch -= 1.0f;
        if (glfwGetKey(win, GLFW_KEY_S) == GLFW_PRESS) ctl.pitch += 1.0f;
        if (glfwGetKey(win, GLFW_KEY_A) == GLFW_PRESS) ctl.roll -= 1.0f;
        if (glfwGetKey(win, GLFW_KEY_D) == GLFW_PRESS) ctl.roll += 1.0f;
        ctl.assist = app.assist;
        updateAircraft(app.ac, dt, aircraftSpec, ctl);

        glm::mat4 M = updatePlanePose(app.ac, plane, app.planeScale, app.planePivot, aircraftSpec.modelYaw);
        View v = updateCamera(app.cam, app.ac, M, dt, (float)app.fbW / (float)app.fbH);
        const SkyLook look = skyLook(app.sky);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        drawSky(app.sky, look, v.view, v.proj, v.eye);

        // cena: terreno, hangares, luzes (pecas), pista e aviao
        beginScene(prog, v, app.ac, app.sky, look);
        setModelMatrix(prog, glm::mat4(1.0f));
        terrain.draw(prog);
        hangars.draw(prog);
        lightFixtures.draw(prog);
        setModelMatrix(prog, glm::scale(glm::mat4(1.0f), glm::vec3(cfg::RUNWAY_SCALE)));
        runway.draw(prog);
        drawPlane(prog, plane, M, app.ac);

        drawRunwayLights(ptProg, lights, v.view, v.proj, v.eye, (float)now, app.sky.night, app.fbH);

        glfwSwapBuffers(win);

        if (now - titleT > 0.25) {                         // HUD na barra de titulo, 4 vezes por segundo
            titleT = now;
            updateTitle(win, app.ac, app.told, app.assist, app.cam.mode, skyTitle(app.sky));
        }
    }

    runway.destroy(); plane.destroy(); terrain.destroy(); hangars.destroy(); lightFixtures.destroy();
    destroySky(app.sky);
    glDeleteProgram(prog); glDeleteProgram(skyProg); glDeleteProgram(ptProg);
    glfwDestroyWindow(win);
    glfwTerminate();
    return 0;
}