#include "render.hpp"

#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <cmath>
#include <cstdio>

// ---- pose do aviao: altura sobre o solo/pista e matriz de modelo ----
glm::mat4 updatePlanePose(Aircraft& ac, const Model& plane, float planeScale, const glm::vec3& planePivot,
                          float modelYaw) {
    float airBlend = 0.0f;
    glm::vec3 planePivotUse = planePivot;
    {   // as rodas tocam na pista no solo; no ar mantem-se a altura sobre a pista
        float minimum = 0.0f;
        if (ac.height < 16.0f)        // acima disto o contacto com o solo ja nao entra na posicao
            minimum = plane.minimumHeightAtPitch(planePivot, planeScale, modelYaw, ac.pitch);
        // no solo roda-se em torno das rodas; em voo, em torno do centro do aviao (transicao nos primeiros 15 m)
        airBlend = glm::smoothstep(0.0f, 15.0f, ac.height);
        planePivotUse = glm::mix(planePivot, glm::vec3(planePivot.x, 0.5f * (plane.bmin.y + plane.bmax.y),
                                                       planePivot.z), airBlend);
        float yGround = ac.height - minimum + 0.01f;
        float yAir = ac.height + (0.5f * (plane.bmin.y + plane.bmax.y) - planePivot.y) * planeScale;
        ac.pos.y = glm::mix(yGround, yAir, airBlend);
    }

    glm::mat4 M(1.0f);
    M = glm::translate(M, ac.pos);
    {   // orientacao livre: colunas = eixos locais x (esquerda), y (cima), z (frente) no mundo
        glm::mat4 R(1.0f);
        R[0] = glm::vec4(glm::cross(ac.up, ac.fwd), 0.0f);
        R[1] = glm::vec4(ac.up, 0.0f);
        R[2] = glm::vec4(ac.fwd, 0.0f);
        M = M * R;
    }
    M = glm::rotate(M, glm::radians(modelYaw), glm::vec3(0, 1, 0));
    M = glm::scale(M, glm::vec3(planeScale));
    M = glm::translate(M, -planePivotUse);
    return M;
}

// ---- camara ----
View updateCamera(Camera& cam, const Aircraft& ac, const glm::mat4& M, float dt, float aspect) {
    // camara de seguimento: horizonte sempre nivelado, atras do rumo do aviao (como no inicio da descolagem).
    // Em picadas verticais ou de pernas para o ar o rumo nao e fiavel: a camara mantem o ultimo rumo.
    glm::vec3 wantF = cam.f, wantU = glm::vec3(0.0f, 1.0f, 0.0f);
    {
        glm::vec3 h(ac.fwd.x, 0.0f, ac.fwd.z);
        if (glm::length(h) > 0.35f && ac.up.y > 0.0f) wantF = glm::normalize(h);
    }
    const bool camFirst = !cam.init;
    if (camFirst) { cam.f = wantF; cam.u = wantU; cam.init = true; }
    {
        float k = 1.0f - std::exp(-4.0f * dt);
        glm::vec3 f = cam.f + (wantF - cam.f) * k;
        f = glm::length(f) > 1e-4f ? glm::normalize(f) : wantF;
        glm::vec3 u = cam.u + (wantU - cam.u) * k;
        u = u - f * glm::dot(f, u);
        u = glm::length(u) > 1e-4f ? glm::normalize(u) : wantU;
        cam.f = f; cam.u = u;
    }
    View v;
    glm::vec3 target = ac.pos + cam.u * 2.5f, eye;
    glm::vec3 up(0.0f, 1.0f, 0.0f);
    if (cam.mode == 1) {       // a orbita (rato) e centrada no proprio aviao; so o rumo da camara e suavizado
        float y = glm::radians(cam.yaw), p = glm::radians(cam.pitch);
        glm::vec3 camR = glm::cross(cam.f, cam.u);
        eye = target + cam.dist * (std::cos(p) * std::sin(y) * camR + std::sin(p) * cam.u -
                                   std::cos(p) * std::cos(y) * cam.f);
        v.view = glm::lookAt(eye, target, cam.u);
    } else if (cam.mode == 2) {
        const glm::vec3 localEye(1.15f, 0.95f, 0.15f);
        const glm::vec3 localFocus(1.0f, 0.80f, -4.0f);
        eye = glm::vec3(M * glm::vec4(localEye, 1.0f));
        target = glm::vec3(M * glm::vec4(localFocus, 1.0f));
        up = glm::normalize(glm::mat3(M) * up);
        v.view = glm::lookAt(eye, target, up);
    }
    v.eye = eye;
    v.proj = glm::perspective(glm::radians(60.0f), aspect, 1.0f, 20000.0f);
    return v;
}

// ---- uniformes da cena: camara, luz pontual, neblina ----
void beginScene(GLuint prog, const View& v, const Aircraft& ac, const Sky& sky, const SkyLook& look) {
    glUseProgram(prog);
    glm::vec3 lightPos = ac.pos + sky.lightOff;
    glUniformMatrix4fv(glGetUniformLocation(prog, "uView"), 1, GL_FALSE, &v.view[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(prog, "uProj"), 1, GL_FALSE, &v.proj[0][0]);
    glUniform3f(glGetUniformLocation(prog, "uLightPos"), lightPos.x, lightPos.y, lightPos.z);
    glUniform3f(glGetUniformLocation(prog, "uLightColor"), look.lightCol.r, look.lightCol.g, look.lightCol.b);
    glUniform3f(glGetUniformLocation(prog, "uViewPos"), v.eye.x, v.eye.y, v.eye.z);
    glUniform3f(glGetUniformLocation(prog, "uSky"), look.horizon.r, look.horizon.g, look.horizon.b);   // neblina = cor do horizonte
    glUniform1f(glGetUniformLocation(prog, "uAmbient"), look.ambient);
    glUniform1f(glGetUniformLocation(prog, "uFog"), 0.00018f);
}

// matriz de modelo e matriz normal do proximo desenho
void setModelMatrix(GLuint prog, const glm::mat4& M) {
    glm::mat3 nm = glm::transpose(glm::inverse(glm::mat3(M)));
    glUniformMatrix4fv(glGetUniformLocation(prog, "uModel"), 1, GL_FALSE, &M[0][0]);
    glUniformMatrix3fv(glGetUniformLocation(prog, "uNormalMat"), 1, GL_FALSE, &nm[0][0]);
}

// ---- aviao: corpo, trem de aterragem e helice ----
void drawPlane(GLuint prog, const Model& plane, const glm::mat4& M, const Aircraft& ac) {
    setModelMatrix(prog, M);
    plane.draw(prog, 0);
    const float gearT = glm::clamp(ac.gearRetraction, 0.0f, 1.0f);
    const float gearBlend = gearT * gearT * (3.0f - 2.0f * gearT);
    // Ki-61: trem principal de via larga (4 m) que recolhe PARA DENTRO. Cada perna roda
    // ~90 graus em torno de um eixo longitudinal no topo da perna, junto a asa, e a roda
    // fica deitada no interior da asa. A roda de cauda (versoes iniciais) roda para a
    // frente, para dentro da fuselagem. Pivos em coordenadas do modelo OBJ.
    auto drawGearPart = [&](int group, const glm::vec3& pivot, float angle, const glm::vec3& axis) {
        glm::mat4 G = glm::translate(M, pivot);
        G = glm::rotate(G, angle, axis);
        G = glm::translate(G, -pivot);
        setModelMatrix(prog, G);
        plane.draw(prog, group);
    };
    if (gearBlend < 1.0f) {
        const float swing = glm::half_pi<float>() * gearBlend;
        const glm::vec3 legL(-0.77f, 0.60f, -0.83f), legR(0.77f, 0.60f, -0.83f);   // 0.60 = a meio da espessura da asa: a roda fica dentro dela
        const glm::vec3 tailPivot(0.0f, 0.80f, 1.40f), zAxis(0, 0, 1), xAxis(1, 0, 0);
        drawGearPart(5, legL, +swing, zAxis);      // esquerda: o fundo da perna roda para +X (para dentro)
        drawGearPart(8, legL, +swing, zAxis);
        drawGearPart(6, legR, -swing, zAxis);      // direita: para -X (para dentro)
        drawGearPart(9, legR, -swing, zAxis);
        drawGearPart(7, tailPivot, +swing, xAxis); // cauda: o fundo roda para -Z do modelo (frente)
    }
    // helice: gira em torno do eixo do nariz
    const glm::vec3 propellerPivot(0.0f, 0.74f, -1.56f);
    glm::mat4 propellerModel = glm::translate(M, propellerPivot);
    propellerModel = glm::rotate(propellerModel, glm::radians(ac.rotorAngle),
                                 glm::vec3(0.0f, 0.0f, 1.0f));
    propellerModel = glm::translate(propellerModel, -propellerPivot);
    setModelMatrix(prog, propellerModel);
    plane.draw(prog, 4);
}

// ---- HUD na barra de titulo ----
void updateTitle(GLFWwindow* win, const Aircraft& ac, const Told& told, bool assist, int camMode,
                 const char* skyTitle) {
    char t[320];
    if (ac.phase == Phase::Ready) {
        std::snprintf(t, sizeof t,
                      "PRE-VOO | Ki-61 | Vr %.0f km/h, descola ~%.0f km/h, corrida ~%.0f m | %s | M dia/noite | Enter descolar | 1/2 camera",
                      told.rotationKmh, told.liftoffKmh, told.groundRoll, skyTitle);
    } else {
        const char* label = (ac.manual && ac.phase != Phase::Crashed)
                                ? (assist ? "MANUAL: W/S picada, A/D rolamento, L estabilizador ON"
                                          : "MANUAL: W/S picada, A/D rolamento, L estabilizador OFF")
                                : phaseName(ac.phase);
        std::snprintf(t, sizeof t,
                      "%s | alt %.0f m | vel %.0f km/h | subida %.1f m/s | trem %.0f%% | picada %.0f° rol %.0f° | cam %d | R reiniciar | %s",
                      label, ac.height, ac.speed * 3.6f, ac.verticalSpeed,
                      ac.gearRetraction * 100.0f, ac.pitch, ac.roll, camMode, skyTitle);
    }
    glfwSetWindowTitle(win, t);
}
