# Projeto Avião: Simulador de Descolagem

Simulação do procedimento de descolagem de uma aeronave.

- **Aluno:** Diogo Rafael Nunes Freire Nogueira, n.º 53851

O programa carrega malhas .obj (Kawasaki Ki-61 Hien, pista, terreno, hangares e luzes da pista), renderiza-as com iluminação Phong a partir de uma luz pontual e simula a descolagem do avião com um modelo físico simples, passando depois ao voo manual.

## Requisitos do enunciado

| Requisito                               | Onde está                                         |
|-----------------------------------------|---------------------------------------------------|
| Aeronave e pista em .obj                | `models/kawasaki.obj`, `models/runway_short.obj`  |
| Carregamento das malhas em memória      | `src/model.cpp` (tinyobjloader + stb_image)       |
| OpenGL moderno (shaders, VAO/VBO)       | `src/main.cpp`, `shaders/`                        |
| Rotação e translação c/ rato e teclado  | rato: câmara; teclado: avião (ver Controlos)      |
| Luz pontual e sombreamento de Phong     | `shaders/SimpleFragmentShader.fragmentshader`     |
| Descolagem (com dados TOLD)             | `predictTakeoff()` em `src/main.cpp`              |

## Extras

Hangares, luzes da pista, skybox dia/noite, terreno, texturas, trem retrátil, voo manual, entre outros

## Organização

```text
projetoaviao/
├── common/             carregador de shaders
├── external/           stb_image e tinyobjloader (cabeçalhos únicos)
├── models/             avião, pista, terreno, hangares e luzes da pista (OBJ/MTL)
├── shaders/            shaders GLSL (cena com Phong, céu, luzes da pista)
├── skybox/             skyboxes diurno/noturno e respetiva configuração (skies.txt)
├── src/                código C++ (main.cpp, model.cpp/hpp)
├── textures/           texturas do avião e dos hangares
├── 02-assignment.pdf   enunciado
└── Makefile            compilação principal
```

As pastas `obj/` e `bin/` são geradas pela compilação.

## Compilar e executar (Linux)

Dependências (Debian/Ubuntu, incluindo WSL2):

```sh
sudo apt install build-essential libglfw3-dev libglew-dev libglm-dev
```

Na pasta `projetoaviao`:

```sh
make
make run
```

O caminho da pasta é fixado na compilação: se moveres a pasta, faz `make clean && make`. Em WSL2, o `make run` define automaticamente `GALLIUM_DRIVER=d3d12`. `make clean` apaga `obj/` e `bin/`.

## Controlos

- **Enter:** inicia a manobra de descolagem.
- **R:** retoma a situação inicial, "recomeça o programa" sem o fechar.
- **M:** alterna entre modo diurno e noturno, só antes da descolagem.
- **1:** câmara padrão: arrastar com o botão esquerdo do rato orbita em torno do avião e scroll ajusta o zoom.
- **2:** câmara assente na asa.
- **W / S:** nariz para baixo / para cima, só depois de o trem estar 100% recolhido.
- **A / D:** asa esquerda / direita para baixo (rolamento), só depois de o trem estar 100% recolhido.
- **L:** liga/desliga o estabilizador (ligado por defeito, ver "Voo manual").
- **Esc:** sair.

O título da janela funciona como HUD: antes de descolar mostra os valores TOLD previstos; durante o voo mostra a fase, a altitude, a velocidade, a razão de subida, a percentagem de trem recolhido e a atitude.

## Iluminação e sombreamento

- Sombreamento de **Phong por fragmento** (`SimpleFragmentShader`): componente ambiente, difusa (`max(N·L, 0)`) e especular (`reflect` e `pow` com o brilho Ns do material).
- **Luz pontual:** posicionada a 850 m do avião, na direção do sol (ou da lua) da skybox escolhida, e acompanha o avião. Dada a distância, comporta-se quase como luz direcional.
- A cor da luz, o nível de ambiente, a direção da luz e a cor da neblina de cada céu vêm de `skybox/skies.txt`.
- Neblina exponencial com a cor do horizonte, e correção gama (2,2) no final.
- As cores vêm das texturas (`map_Kd`) ou do `Kd` do .mtl quando não há textura.

## Física da descolagem

O movimento não segue rampas fixas: é um modelo de ponto material no plano vertical, integrado em passos de 10 ms, onde a velocidade, a atitude e a subida resultam das forças.

- **Tração:** limitada a baixa velocidade (tração estática) e depois `η·P/v`, com P = 1175 hp. O piloto avança o acelerador em 3 s.
- **Resistência:** parasita (com trem descido e flaps de descolagem, que diminui com a recolha) + induzida, mais resistência ao rolamento na pista.
- **Sustentação:** `L = ½·ρ·v²·S·CL`, com CL linear no ângulo de ataque até CLmax. O avião descola quando `L ≥ peso`, não a uma velocidade fixa.
- **Piloto automático:** a cauda sobe aos 95 km/h; aos 140 km/h puxa o nariz (atitude pretendida de 11°, com resposta suavizada e taxa limitada); depois acelera até 230 km/h durante a subida, ajustando a atitude.

Valores registados do Ki-61-I: comprimento 8,94 m, envergadura 12,0 m, área alar 20 m², massa 3470 kg, potência 1175 hp e razão de subida inicial 15,2 m/s.

Estimativas: coeficientes aerodinâmicos, CLmax = 1,55 (Vs ≈ 150 km/h), tração estática (11 kN), resistência ao rolamento e as velocidades de manobra do piloto.

### TOLD (dados de descolagem)

Antes de descolar, o programa corre a mesma simulação sem desenhar e mostra o resultado no título da janela e na consola:

- rotação a **140 km/h**;
- descolagem a **~170 km/h**;
- corrida de **~430 m** (cerca de 19 s).

### Pista

O asfalto tem 45 m de largura e o troço modelado tem cerca de 1265 m. O avião arranca 30 m depois da cabeceira.

### Hélice

Parada até ao início da corrida e acelera gradualmente em 5 s. A rotação mostrada é limitada a 1800°/s (300 rpm) para evitar o efeito estroboscópico a 60 Hz; não é a rotação real do motor.

O modelo do avião tem uma envergadura ligeiramente maior (~12,6 m) do que a real (12,0 m) porque é escalado pelo comprimento.

## Atitude no solo e trem de aterragem

O Ki-61 tem roda de cauda. Parado apoia-se em três pontos, com o nariz levantado ~13° (calculado a partir da geometria do modelo).

O trem principal tem via de 4 m e recolhe para dentro: cada perna roda ~90° em torno de um eixo longitudinal, a meio da espessura da asa, e a roda fica deitada dentro dela. A recolha começa aos 10 m de altura e demora 6 s (estimativa).

Roda traseira e garfo rodam para a frente e ficam dentro da fuselagem.

## Voo manual

Quando o trem fica 100% recolhido, o controlo passa a manual (atualizado no título da janela). A orientação do avião é livre em 3D, sem limites de ângulo.

- **W/S** comandam a taxa de picada (15°/s) e **A/D** a de rolamento (70°/s), com resposta suavizada. Sem comando, o avião mantém a atitude.
- **Curvar** = rolamento + picada: a sustentação inclinada tem uma componente horizontal que curva a trajetória. Um leme automático alinha o nariz com a trajetória (voo coordenado).
- **Perda:** a asa perde sustentação acima do ângulo de ataque crítico e, perto dele, o comando de picada perde autoridade para o avião não "capotar". Por isso um loop precisa de velocidade (o loop de teste fecha-se a ~250 km/h depois de um pequeno mergulho) e, a baixa velocidade, o avião deixa de responder à picada.
- **Estabilizador (L):** ligado, as asas nivelam-se sozinhas quando largas A/D, mas só abaixo de 90° de rolamento e com a picada abaixo de ~58°, para não estragar loops. Desligado, o voo é totalmente manual (podes ficar invertido).
- **Câmara 1:** mantém sempre o horizonte nivelado e segue o rumo do avião com suavização. Em picadas verticais ou voo invertido, o rumo deixa de ser fiável e a câmara mantém o último rumo válido.
- **Câmara 2 (asa):** roda com o avião, loops incluídos.
- O voo termina com contacto com o solo (pista ou terreno; a altura do terreno é lida da malha) e **R** reinicia. Não há aterragem simulada nem acelerador: a potência é a de descolagem.
- O controlo manual começa alguns segundos depois de o avião passar os 10 m de altura (quando a recolha do trem completa os 6 s): convém subir antes de acrobacias.

## Ambiente (extras)

- **Skybox** (`skybox/`): dois céus em cubemap, "dia azul" e "noite escura", configurados em `skybox/skies.txt` (cor e direção da luz, ambiente, neblina e se é noite). Para acrescentar um céu, junta uma pasta com `px, nx, py, ny, pz, nz .jpg` e uma linha nova no ficheiro.
- **Terreno** (`models/terrain.obj`): relevo a toda a volta, malha regular e contínua (grelha de 301×301, passo de 120 m), derivada dos dados SRTM da NASA/USGS (tile N32W017) e nivelada sob a pista. A mesma malha serve para detetar o contacto com o solo.
- **Hangares** (`models/hangars.obj`): três hangares de um dos lados da pista, com uma placa de betão, perto da zona de partida.
- **Texturação:** avião (mapas BaseColor), hangares (parede, porta, telhado) e placa de betão.

### Luzes da pista (modo noturno)

As luzes são objetos de `models/runway_lights.obj`: uma peça por luz, com o nome a indicar o tipo e o material a cor. De dia veem-se as peças; à noite cada uma ganha também um ponto luminoso (a posição e a cor são lidas do próprio OBJ). Seguem a prática ICAO para uma descolagem no sentido +Z:

- bordos brancos a cada 60 m (âmbar no último terço);
- eixo a cada 15 m (branco, depois alternado vermelho/branco e vermelho nos últimos 300 m);
- barra verde na cabeceira de partida e barra vermelha no fim da pista.